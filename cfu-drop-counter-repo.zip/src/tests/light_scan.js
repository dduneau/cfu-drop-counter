// Light scans (transmitted light: dark colonies on light agar).
// Checks: the scan type is recognised, Snap finds the dark rims, detection runs on the
// whole plate, and how the counts compare with the hand counts of the same plate
// (tests/data/COUNTS_light_manual.csv, counted on the full-resolution scan).
// SCAN=/path/to/full-resolution.png node tests/light_scan.js  also checks a full-size scan
// (the app reduces it to ~300 px between drops, so counts should be the same).
const path = require('path');
const APP = 'file://' + path.resolve(__dirname, '../../index.html');
const SCAN = process.env.SCAN || path.resolve(__dirname, 'data', 'scan_light.jpg');
const { chromium } = require('playwright');
const fs = require('fs');
const MAN = fs.readFileSync(path.resolve(__dirname, 'data', 'COUNTS_light_manual.csv'), 'utf8').trim().split(/\r?\n/).slice(1).map((l) => l.split(';')[6]);
const TRUE_CORNERS = [[330, 271], [3458, 256], [333, 2256], [3462, 2241]]; // A1, A12, H1, H12 at half resolution
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1180, height: 820 } });
  const errs = []; p.on('pageerror', (e) => errs.push(e.message));
  await p.goto(APP); await p.waitForTimeout(300);
  await p.setInputFiles('#file', SCAN); await p.waitForFunction(() => !document.querySelector('#to-grid').disabled, null, { timeout: 120000 });
  const info = await p.evaluate(() => ({ bg: S.bg, w: S.image.w, h: S.image.h }));
  const k = info.w / 3672; // corners above are for the half-resolution copy
  console.log('scan', path.basename(SCAN), info.w + '×' + info.h, '| scan type recognised as', info.bg);
  await p.click('#to-grid'); await p.waitForTimeout(200);
  // corners placed by hand, roughly (about a tenth of a well off), then Snap
  const rough = TRUE_CORNERS.map(([x, y], j) => [(x + [22, -18, 15, -25][j]) * k, (y + [-20, 16, 24, -14][j]) * k]);
  const snap = await p.evaluate((c) => { S.grid.c = c; const r = snapGrid(); if (r.ok) { S.grid.c = r.corners; invalidateCal(); } return r; }, rough);
  const err = Math.max(...snap.corners.map((c, j) => Math.hypot(c[0] / k - TRUE_CORNERS[j][0], c[1] / k - TRUE_CORNERS[j][1])));
  console.log('snap ok', snap.ok, 'resid', snap.resid.toFixed(3), '| worst corner off by', err.toFixed(1), 'px (half-res), drop spacing 286');
  const t = Date.now();
  const r = await p.evaluate(async () => { await detectWells(allWells(), '#t-prog'); return { n: allWells().map((i) => W(i).m.length), cal: S.cal }; });
  console.log('detection on 96 drops', ((Date.now() - t) / 1000).toFixed(1), 's | colony radius', r.cal.r0.toFixed(1), 'px at scale', r.cal.f.toFixed(2));
  for (let row = 0; row < 8; row++) console.log('ABCDEFGH'[row], r.n.slice(row * 12, row * 12 + 12).join('\t'));
  // against the hand counts: drops counted by hand (not Inf or NA), and those with 30 colonies or fewer
  const cmp = (max) => { const e = []; const far = [];
    r.n.forEach((v, i) => { const m = MAN[i]; if (m === 'Inf' || m === 'NA' || +m > max) return; e.push(v - +m); if (Math.abs(v - +m) > 2) far.push(`${'ABCDEFGH'[(i / 12) | 0]}${(i % 12) + 1} ${m}->${v}`); });
    const mae = e.reduce((a, x) => a + Math.abs(x), 0) / e.length, bias = e.reduce((a, x) => a + x, 0) / e.length;
    return `${e.filter((x) => Math.abs(x) <= 2).length}/${e.length} within ±2, ${e.filter((x) => x === 0).length} exact, mean abs error ${mae.toFixed(2)}, bias ${bias >= 0 ? '+' : ''}${bias.toFixed(2)}` + (far.length ? ` | off by more than 2: ${far.join(', ')}` : ''); };
  console.log('vs hand counts, drops <= 30:', cmp(30));
  console.log('vs hand counts, all counted drops:', cmp(Infinity));
  // the Tune preview and the scan-type switch
  await p.click('#to-tune'); await p.waitForTimeout(1500);
  const pressed = await p.evaluate(() => [...document.querySelectorAll('#bgmode button')].map((x) => x.dataset.bg + ':' + x.getAttribute('aria-pressed')).join(' '));
  console.log('Tune scan-type buttons', pressed);
  await p.screenshot({ path: path.resolve(__dirname, 'out', 'light_tune.png') });
  await p.click('#bgmode [data-bg="dark"]'); await p.waitForTimeout(300);
  const after = await p.evaluate(async () => { await ensureCal(); return { bg: S.bg, calBg: S.cal.bg }; });
  console.log('switched to', after.bg, '| calibration redone for', after.calBg);
  console.log('errors', errs);
  await b.close();
})();
