const path = require('path');
const APP = 'file://' + path.resolve(__dirname, '../../index.html');
const D = (f) => path.resolve(__dirname, 'data', f), O = (f) => path.resolve(__dirname, 'out', f);
const SAMPLE = path.resolve(__dirname, 'data', 'sample_old.jpg'); // the earlier example scan (reflected light)
const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch(); const ctx = await b.newContext({ acceptDownloads: true, viewport:{width:1180,height:820} }); const p = await ctx.newPage();
  await p.goto(APP); await p.waitForTimeout(300);
  await p.screenshot({ path: O('shot-setup2.png') });
  await p.click('#btn-sample'); await p.waitForTimeout(600); await p.click('#to-grid'); await p.waitForTimeout(200);
  await p.click('[data-view=\"tune\"]'); await p.click('#manual-only'); await p.waitForTimeout(200); await p.click('[data-view="export"]'); await p.waitForTimeout(200);
  const [d] = await Promise.all([p.waitForEvent('download', { timeout: 5000 }), p.click('#x-save')]);
  console.log('download', d.suggestedFilename(), (await require('fs').promises.readFile(await d.path(),'utf8')).split('\r\n')[1]);
  await b.close();
})();
