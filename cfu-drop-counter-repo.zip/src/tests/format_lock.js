// Plate format is locked once the plate has counts; clearing the counts unlocks it (and can be undone).
const path = require('path');
const APP = 'file://' + path.resolve(__dirname, '../../index.html');
const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch(); const errs = [];
  const p = await (await b.newContext({ viewport: { width: 1180, height: 820 } })).newPage(); p.on('pageerror', (e) => errs.push(e.message));
  await p.goto(APP); await p.waitForTimeout(300);
  await p.click('#btn-sample'); await p.waitForTimeout(700);
  const lock = () => p.evaluate(() => `rows ${document.querySelector('#nrows').disabled ? 'locked' : 'open'}, cols ${document.querySelector('#ncols').disabled ? 'locked' : 'open'}, notice ${document.querySelector('#fmt-lock').hidden ? 'hidden' : 'shown'}`);
  console.log('scan loaded, nothing counted:', await lock());
  await p.click('#to-grid'); await p.waitForTimeout(200); await p.click('[data-view=\"tune\"]'); await p.click('#detect-all'); await p.waitForFunction(() => S.view === 'count', null, { timeout: 60000 });
  const counted = await p.evaluate(() => JSON.stringify(S.wells));
  await p.click('[data-view="setup"]'); await p.waitForTimeout(200);
  console.log('after detection:', await lock());
  // even a forced change is refused while counts exist
  await p.evaluate(() => { const e = document.querySelector('#nrows'); e.disabled = false; e.value = 6; e.dispatchEvent(new Event('input', { bubbles: true })); });
  console.log('forced change refused:', await p.evaluate(() => S.rows === 8 && !!S.grid), '| counts intact:', counted === (await p.evaluate(() => JSON.stringify(S.wells))));
  await p.click('#fmt-clear'); await p.click('#fmt-no'); console.log('Keep: counts intact', counted === (await p.evaluate(() => JSON.stringify(S.wells))), '|', await lock());
  await p.click('#fmt-clear'); await p.click('#fmt-yes'); await p.waitForTimeout(200);
  console.log('after Clear:', await lock(), '| wells left', await p.evaluate(() => Object.keys(S.wells).length));
  await p.click('[data-view="count"]'); await p.waitForTimeout(200); await p.click('#c-undo'); await p.waitForTimeout(200);
  console.log('Undo on Count brings the counts back:', counted === (await p.evaluate(() => JSON.stringify(S.wells))).replace('"seen":false', '"seen":false') || 'seen differs only');
  await p.click('[data-view="setup"]'); await p.waitForTimeout(200); console.log('and the format is locked again:', await lock());
  // a single drop looked at counts too (a checked drop with no colony is a count of 0)
  await p.click('#fmt-clear'); await p.click('#fmt-yes'); await p.click('[data-view="count"]'); await p.waitForTimeout(200); await p.click('[data-view="setup"]'); await p.waitForTimeout(200);
  console.log('after looking at one drop:', await lock());
  console.log('errors', errs); await b.close();
})();
