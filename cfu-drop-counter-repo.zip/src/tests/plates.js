const path = require('path');
const APP = 'file://' + path.resolve(__dirname, '../../index.html');
const D = (f) => path.resolve(__dirname, 'data', f), O = (f) => path.resolve(__dirname, 'out', f);
const SAMPLE = path.resolve(__dirname, '../assets/sample.jpg');
const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch(); const errs = [];
  const ctx = await b.newContext({ viewport: { width: 1180, height: 820 }, acceptDownloads: true }); const p = await ctx.newPage();
  p.on('pageerror', (e) => errs.push(e.message));
  await p.goto(APP); await p.waitForTimeout(400);
  // plate 1: full scan
  await p.setInputFiles('#file', D('scan.jpg')); await p.waitForFunction(() => !document.querySelector('#to-grid').disabled);
  await p.fill('[data-f="2"][data-k="value"]', 'plate01');
  await p.click('#to-grid'); await p.evaluate(() => { S.grid.c = [[346, 325], [2683, 329], [340, 1784], [2679, 1785]]; });
  await p.click('#detect-all'); await p.waitForFunction(() => S.view === 'count', null, { timeout: 60000 });
  for (let k = 0; k < 4; k++) await p.click('#c-next2');
  const p1 = await p.evaluate(() => JSON.stringify(S.wells));
  // plate 2: new plate with the example scan
  await p.click('[data-view="setup"]'); await p.click('#new-plate'); await p.waitForTimeout(300);
  await p.click('#btn-sample'); await p.waitForTimeout(800);
  await p.fill('[data-f="2"][data-k="value"]', 'plate02');
  await p.click('#to-grid'); await p.waitForTimeout(200); await p.click('#detect-all'); await p.waitForFunction(() => S.view === 'count', null, { timeout: 60000 });
  await p.click('[data-view="setup"]'); await p.waitForTimeout(600);
  console.log('list:', JSON.stringify(await p.$$eval('#plate-list .fileitem b', (e) => e.map((x) => x.textContent))));
  await p.screenshot({ path: O(O('shot-plates.png')) });
  // open plate01 again
  const id1 = await p.evaluate(() => PLATES.find((x) => x.name === 'plate01').id);
  await p.click(`[data-popen="${id1}"]`); await p.waitForFunction(() => S.view === 'count', null, { timeout: 10000 });
  console.log('plate01 restored identical:', p1 === (await p.evaluate(() => JSON.stringify(S.wells))), 'scan', await p.evaluate(() => S.image.name), 'cur drop', await p.evaluate(() => wellName(S.cur)));
  // reload resumes plate01
  await p.waitForTimeout(500); await p.reload(); await p.waitForTimeout(1800);
  console.log('after reload:', await p.evaluate(() => plateNameOf(S)), await p.evaluate(() => S.view), 'plates', await p.evaluate(() => PLATES.length));
  // another plate on this scan: shares the image
  await p.click('[data-view="export"]'); await p.click('#x-nextplate'); await p.waitForTimeout(500);
  console.log('next plate: view', await p.evaluate(() => S.view), 'plates', await p.evaluate(() => PLATES.length), 'same image key', await p.evaluate(() => PLATES[0].imgKey === PLATES.find((x) => x.name === 'plate01').imgKey), 'replicate', await p.evaluate(() => S.fields[1].value));
  await p.fill('[data-f="2"][data-k="value"]', 'plate03').catch(() => {});
  await p.evaluate(() => { S.fields[2].value = 'plate03'; S.grid.c = [[329, 2313], [2666, 2309], [326, 3769], [2663, 3770]]; save(); });
  await p.click('#detect-all'); await p.waitForFunction(() => S.view === 'count', null, { timeout: 60000 });
  // Load tab: pick all three plates, well layout without plate column -> 3 spots per fly
  await p.click('[data-view="load"]'); await p.waitForTimeout(800);
  await p.evaluate(() => { for (const x of PLATES) LOADST.picked[x.id] = true; renderLoad(); }); await p.waitForTimeout(300);
  await p.setInputFiles('#l-layout', D('layout_wells.csv')); await p.waitForTimeout(600);
  console.log('load over plates:', JSON.stringify(await p.evaluate(() => ({ flies: loadRes.res && loadRes.res.flies.length, spotsPerFly: loadRes.res && loadRes.res.flies[0].Spots, plates: loadRes.res && loadRes.res.flies[0].Plates, blocking: loadRes.res && loadRes.res.blocking.length }))));
  await p.screenshot({ path: O(O('shot-load-plates.png')) });
  // backup marks
  await p.click('[data-view="count"]'); const [d] = await Promise.all([p.waitForEvent('download'), p.click('#c-progress')]); await p.waitForTimeout(500);
  console.log('backup recorded:', await p.evaluate(() => !!plateMeta(S.sid).backup));
  // delete plate02 (with confirm)
  await p.click('[data-view="setup"]'); await p.waitForTimeout(300);
  const id2 = await p.evaluate(() => PLATES.find((x) => x.name === 'plate02').id);
  await p.click(`[data-pdel="${id2}"]`); await p.click(`[data-pdel-yes="${id2}"]`); await p.waitForTimeout(500);
  console.log('after delete:', await p.evaluate(() => PLATES.map((x) => x.name).join(',')));
  const keys = await p.evaluate(async () => { const db = await DB.open(); return await new Promise((r) => { const q = db.transaction('kv').objectStore('kv').getAllKeys(); q.onsuccess = () => r(q.result); }); });
  console.log('storage keys:', keys.filter((k) => /^img:/.test(k)).length, 'images,', keys.filter((k) => /^st:/.test(k)).length, 'plate states');
  // migration from the old single-plate format
  const ctx2 = await b.newContext(); const q = await ctx2.newPage(); q.on('pageerror', (e) => errs.push('mig ' + e.message));
  await q.goto(APP); await q.waitForTimeout(400);
  await q.evaluate(async () => {
    const bin = atob(SAMPLE_JPG_B64), u8 = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
    const st = Object.assign(defaults(), { image: { name: 'old.jpg', w: 2047, h: 1402 }, grid: { c: [[147, 154], [1900, 157], [143, 1248], [1897, 1249]], maskK: 0.46 }, wells: { A1: { m: [[1, 2, 0]], seen: true, tm: [] } }, view: 'count', load: { files: [], layout: null, cur: true, type: '', mode: 'censor', maxCFU: 40, homog: 200, logbase: 2, dupAction: 'keep' } });
    await DB.del('plates'); await DB.del('current'); await DB.put('state', JSON.stringify(st)); await DB.put('image', new Blob([u8], { type: 'image/jpeg' }));
  });
  await q.reload(); await q.waitForTimeout(1800);
  console.log('migrated:', JSON.stringify(await q.evaluate(() => ({ plates: PLATES.length, view: S.view, a1: S.wells.A1 && S.wells.A1.m.length, img: !!img, load: [LOADST.mode, LOADST.maxCFU, LOADST.homog, LOADST.logbase] }))));
  console.log('errors', errs); await b.close();
})();
