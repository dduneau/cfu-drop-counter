const path = require('path');
const APP = 'file://' + path.resolve(__dirname, '../../index.html');
const D = (f) => path.resolve(__dirname, 'data', f), O = (f) => path.resolve(__dirname, 'out', f);
const SAMPLE = path.resolve(__dirname, '../assets/sample.jpg');
const { chromium, webkit } = require('playwright');
const fs = require('fs');
(async () => {
  const b = await chromium.launch();
  const ctx = await b.newContext({ viewport: { width: 1180, height: 820 }, deviceScaleFactor: 1, hasTouch: true });
  const p = await ctx.newPage();
  const errs = []; p.on('pageerror', e => errs.push(e.message)); p.on('console', m => { if (m.type()==='error') errs.push(m.text()); });
  await p.goto(APP);
  await p.waitForTimeout(500);
  await p.screenshot({ path: O('shot-setup-empty.png') });
  await p.setInputFiles('#file', D('scan.jpg'));
  await p.waitForFunction(() => !document.querySelector('#to-grid').disabled);
  // fields
  const vals = ['25/06/2017','1','Traj_Prett_CS_sexdim_plate01'];
  for (let i=0;i<3;i++) await p.fill(`[data-f="${i}"][data-k="value"]`, vals[i]);
  await p.click('#adv summary'); await p.fill('#dil-p', '25');
  await p.screenshot({ path: O('shot-setup.png') });
  await p.click('#to-grid'); await p.waitForTimeout(300);
  await p.screenshot({ path: O('shot-grid-initial.png') });
  // rough corners ~25px off true for top plate, then snap
  await p.evaluate(() => { S.grid.c = [[370,350],[2660,305],[320,1760],[2700,1810]]; drawGrid(); });
  await p.click('#snap'); await p.waitForTimeout(4000);
  const c = await p.evaluate(() => S.grid.c.map(x=>x.map(v=>Math.round(v))));
  console.log('snapped', JSON.stringify(c), await p.textContent('#snap-msg'));
  await p.screenshot({ path: O('shot-grid.png') });
  const t0 = Date.now();
  await p.click('[data-view=\"tune\"]'); await p.click('#detect-all');
  await p.waitForFunction(() => S.view === 'count', null, { timeout: 60000 });
  console.log('detect ms', Date.now()-t0);
  await p.waitForTimeout(400);
  // compare with truth
  const truth = {}; fs.readFileSync(D('COUNTS_25-06-17_1_plate01.csv'),'utf8').trim().split(/\r?\n/).slice(1).forEach(l=>{const f=l.split(';');truth[f[3]]=f[6];});
  const det = await p.evaluate(() => Object.fromEntries(Object.entries(S.wells).map(([k,w])=>[k,w.m.length])));
  let ae=0,n=0,w2=0; for (const k in truth) if (truth[k]!=='Inf') { const e=Math.abs(det[k]-truth[k]); ae+=e; n++; if(e<=2) w2++; }
  console.log('in-app MAE', (ae/n).toFixed(2), 'within2', w2, '/', n);
  await p.screenshot({ path: O('shot-count.png') });
  // tap tests on A1: add one mark in empty area and remove it
  const box = await p.locator('#c-canvas').boundingBox();
  const before = await p.evaluate(() => W(S.cur).m.length);
  await p.mouse.click(box.x + box.width/2 + 150, box.y + box.height/2 + 150);
  const after = await p.evaluate(() => W(S.cur).m.length);
  await p.mouse.click(box.x + box.width/2 + 150, box.y + box.height/2 + 150);
  const after2 = await p.evaluate(() => W(S.cur).m.length);
  console.log('tap add/remove', before, after, after2);
  await p.click('#c-undo'); console.log('undo ->', await p.evaluate(() => W(S.cur).m.length));
  await p.keyboard.press('ArrowRight'); console.log('cur after arrow', await p.evaluate(()=>S.cur));
  await p.keyboard.press('u'); console.log('active after u', await p.evaluate(()=>S.active));
  // go to dense drop D10 for screenshot
  await p.evaluate(() => go(3*12+9)); await p.waitForTimeout(200);
  await p.screenshot({ path: O('shot-count-d10.png') });
  // set state = truth counts and compare CSV byte-for-byte (the reference file has two colony types)
  await p.evaluate(() => { S.types = [{ name: 'Prett', color: '#f5c518', key: 'e' }, { name: 'Unknown', color: '#ef4444', key: 'u' }]; });
  await p.evaluate((truth) => {
    for (let i=0;i<96;i++){ const nm=wellName(i), w=W(i), t=truth[nm]; w.ign=false; w.empty=false; w.tm=[]; if(t==='Inf'){ w.tm[0]=true; w.m=[]; } else { w.m=Array.from({length:+t},()=>[0,0,0]); } }
  }, truth);
  await p.click('[data-view="export"]'); await p.waitForTimeout(300);
  const csv = await p.evaluate(() => buildCSV());
  const ref = fs.readFileSync(D('COUNTS_25-06-17_1_plate01.csv'),'utf8');
  console.log('CSV identical:', csv === ref, csv.length, ref.length, 'name', await p.inputValue('#x-name'));
  if (csv !== ref) { for (let i=0;i<Math.min(csv.length,ref.length);i++) if (csv[i]!==ref[i]) { console.log('diff at', i, JSON.stringify(csv.slice(i-20,i+20)), JSON.stringify(ref.slice(i-20,i+20))); break; } }
  await p.screenshot({ path: O('shot-export.png'), fullPage: true });
  // reload -> resume
  await p.reload(); await p.waitForTimeout(1500);
  console.log('resumed view', await p.evaluate(()=>S.view), await p.textContent('#st-file'));
  // portrait dark
  const ctx2 = await b.newContext({ viewport: { width: 820, height: 1180 }, colorScheme: 'dark', hasTouch: true });
  const p2 = await ctx2.newPage(); p2.on('pageerror', e => errs.push('p2 '+e.message));
  await p2.goto(APP); await p2.waitForTimeout(400);
  await p2.click('#btn-sample'); await p2.waitForTimeout(800);
  await p2.click('#to-grid'); await p2.waitForTimeout(300);
  await p2.click('#snap'); await p2.waitForTimeout(3000); await p2.click('#zoom'); await p2.waitForTimeout(200);
  console.log('sample snap', await p2.textContent('#snap-msg'));
  await p2.screenshot({ path: O('shot-p-grid.png') });
  await p2.click('[data-view=\"tune\"]'); await p2.click('#detect-all'); await p2.waitForFunction(() => S.view === 'count', null, { timeout: 60000 }); await p2.waitForTimeout(300);
  const det2 = await p2.evaluate(() => Object.fromEntries(Object.entries(S.wells).map(([k,w])=>[k,w.m.length])));
  let ae2=0,n2=0; for (const k in truth) if (truth[k]!=='Inf') { ae2+=Math.abs(det2[k]-truth[k]); n2++; } console.log('sample MAE', (ae2/n2).toFixed(2));
  await p2.screenshot({ path: O('shot-p-count.png'), fullPage: true });
  const ctx3 = await b.newContext({ viewport: { width: 400, height: 800 } });
  const p3 = await ctx3.newPage(); await p3.goto(APP); await p3.waitForTimeout(400);
  console.log('phone overflow', await p3.evaluate(() => document.documentElement.scrollWidth > innerWidth || [...document.querySelectorAll('.view')].some(v=>!v.hidden && v.scrollWidth>v.clientWidth)));
  console.log('errors', errs);
  await b.close();
})();
