## Reproduce the app's per-fly loads in R from a COUNTS file and a layout file.
## Run the two functions above first (loadEstimateOneSample and loadEstimate).

counts <- read.table("COUNTS_plate01.csv", header = TRUE, sep = ";",
                     check.names = FALSE, stringsAsFactors = FALSE)
layout <- read.table("layout.csv", header = TRUE, sep = ";",
                     stringsAsFactors = FALSE)

## A layout by ROW: one fly per row, its dilution series across the columns.
## (For a layout by WELL, merge with by = "WELL" instead.)
counts$ROW <- substr(counts$WELL, 1, 1)
d <- merge(layout, counts, by = "ROW")

d$CFU      <- as.numeric(d$Prett)                          # "Inf" = too many to count
d$dilution <- ifelse(d$Dilution <= 1, 1, 1 / d$Dilution)   # factor 25 -> 1/25
d <- d[!is.na(d$CFU) & !is.na(d$dilution), ]                # ignored or unspotted wells

ceiling_cfu <- 30     # highest count still read reliably
homogenate  <- 250    # uL per fly

est <- loadEstimate(cfu = d$CFU, dilution = d$dilution, volume = d$Volume,
                    sampleID = d$ID, maxCFU = ceiling_cfu,
                    ignoreAboveMaxCFU = FALSE,   # FALSE = censored (the app's default)
                    logbase = 10)

est$CFU_per_fly       <- est$load * homogenate
est$log10_CFU_per_fly <- log10(est$CFU_per_fly)
est$LOD_per_fly       <- homogenate / tapply(d$dilution * d$Volume, d$ID, sum)[est$sampleID]
est
