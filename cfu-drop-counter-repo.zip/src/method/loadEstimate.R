loadEstimateOneSample <- function (cfu, dilution, volume, maxCFU, ignoreAboveMaxCFU, logbase = NA)
{
    l <- !is.na(cfu)
    dilution <- dilution[l]
    cfu <- cfu[l]
    vdilution <- dilution * volume
    if (length(cfu) <= 0) {
        warning("No CFU counts to work with!")
        return(list(logload = NA, se.logload = NA, load = NA,
            se.load = NA, code = -1, sumCFU = 0, maxCFU = maxCFU,
            ignoreAboveMaxCFU = ignoreAboveMaxCFU))
    }
    if (length(cfu) != length(dilution)) {
        stop("cfu and dilution should have the same length")
    }
    if (any(cfu < 0)) {
        stop("CFU counts must be positive")
    }
    if (any(dilution <= 0)) {
        stop("Dilution factors must be strinctly positive")
    }
    if (any(dilution > 1)) {
        stop("Dilution cannot exceed one")
    }
    if (!is.na(maxCFU)) {
        belowMaxCFU <- cfu <= maxCFU
        cfu.below <- cfu[belowMaxCFU]
        vdilution.below <- vdilution[belowMaxCFU]
        n.below <- length(cfu.below)
    }
    else {
        belowMaxCFU <- is.finite(cfu)
        cfu.below <- cfu[belowMaxCFU]
        vdilution.below <- vdilution[belowMaxCFU]
        n.below <- length(cfu.below)
    }
    if (!is.na(maxCFU)) {
        aboveMaxCFU <- cfu > maxCFU
        vdilution.above <- vdilution[aboveMaxCFU]
        n.above <- length(vdilution.above)
    }
    else {
        aboveMaxCFU <- NULL
        vdilution.above <- NULL
        n.above <- 0
    }
    sum_cfu <- sum(cfu.below)
    sum_dil <- sum(vdilution.below)
    sum_cfulogdil <- sum(log(vdilution.below) * cfu.below)
    sum_logfact <- sum(lgamma(cfu.below + 1))
    sum_cfulogdil_logfact <- sum_cfulogdil - sum_logfact
    logload_firstguess <- log(sum_cfu/sum_dil)
    if (is.infinite(logload_firstguess))
        logload_firstguess <- 0
    dlogLik.ignoreAbove <- function(llambd) {
        lambd <- exp(llambd)
        dll <- -sum_dil + sum_cfu/lambd
        if (!is.na(maxCFU)) {
            for (dd in vdilution.below) {
                avg <- dd * lambd
                la <- dpois(maxCFU, lambda = avg, log = TRUE) -
                  ppois(maxCFU, lambda = avg, lower.tail = TRUE,
                    log.p = TRUE)
                dll <- dll + dd * exp(la)
            }
        }
        return(dll)
    }
    dlogLik.notIgnoreAbove <- function(llambd) {
        lambd <- exp(llambd)
        dll <- -sum_dil + sum_cfu/lambd
        if (!is.na(maxCFU)) {
            for (dd in vdilution.above) {
                avg <- dd * lambd
                la <- dpois(maxCFU, lambda = avg, log = TRUE) -
                  ppois(maxCFU, lambda = avg, lower.tail = FALSE,
                    log.p = TRUE)
                dll <- dll + dd * exp(la)
            }
        }
        return(dll)
    }
    bounds <- logload_firstguess + c(-5, 5)
    if (ignoreAboveMaxCFU) {
        opt <- try(uniroot(dlogLik.ignoreAbove, interval = bounds,
            extendInt = "downX"), silent = TRUE)
    }
    else {
        opt <- try(uniroot(dlogLik.notIgnoreAbove, interval = bounds,
            extendInt = "downX"), silent = TRUE)
    }
    if ("try-error" %in% class(opt) || is.na(opt$estim.prec)) {
        return(list(logload = NA, se.logload = NA, load = NA,
            se.load = NA, code = -1, sumCFU = sum_cfu, maxCFU = maxCFU,
            ignoreAboveMaxCFU = ignoreAboveMaxCFU))
    }
    est <- opt$root
    lambd <- exp(est)
    lambd2 <- lambd * lambd
    d2ll <- -sum_cfu/(lambd2)
    if (!is.na(maxCFU)) {
        if (ignoreAboveMaxCFU) {
            for (dd in vdilution.below) {
                avg <- lambd * dd
                lF <- ppois(maxCFU, lambda = avg, lower.tail = TRUE,
                  log.p = TRUE)
                lf <- dpois(maxCFU, lambda = avg, log = TRUE)
                f_F <- exp(lf - lF)
                d2ll <- d2ll + dd * dd * f_F * (f_F - 1 + maxCFU/avg)
            }
        }
        else {
            for (dd in vdilution.above) {
                avg <- lambd * dd
                lF <- ppois(maxCFU, lambda = avg, lower.tail = FALSE,
                  log.p = TRUE)
                lf <- dpois(maxCFU, lambda = avg, log = TRUE)
                f_F <- exp(lf - lF)
                d2ll <- d2ll - dd * dd * f_F * (f_F + (1 - maxCFU/avg))
            }
        }
    }
    d2ll <- d2ll * c(lambd2, 1)
    se <- ifelse(d2ll < 0, 1/sqrt(-d2ll), NA)
    if (!is.na(logbase) && logbase > 0) {
        sc <- log(logbase)
        est <- est/sc
        se[1] <- se[1]/sc
    }
    return(list(logload = est, se.logload = se[1], load = lambd,
        se.load = se[2], code = 1, sumCFU = sum_cfu, maxCFU = maxCFU,
        ignoreAboveMaxCFU = ignoreAboveMaxCFU))
}


loadEstimate <- function(cfu, dilution, volume = 5, sampleID = NULL,
                         maxCFU = 50, ignoreAboveMaxCFU = TRUE, logbase = NA) {
  if (is.null(sampleID)) {
    res <- loadEstimateOneSample(cfu, dilution, volume, maxCFU,
                                 ignoreAboveMaxCFU, logbase)
    return(res)
  }
  ld <- split(data.frame(CFU = cfu, Dilution = dilution, Volume = volume), sampleID)
  est <- try(sapply(ld, function(dtmp)
    with(dtmp, loadEstimateOneSample(CFU, Dilution, Volume, maxCFU,
                                     ignoreAboveMaxCFU, logbase))))
  res <- data.frame(sampleID = names(ld),
                    logload = as.numeric(est[1, ]),
                    se.logload = as.numeric(est[2, ]),
                    load = as.numeric(est[3, ]),
                    se.load = as.numeric(est[4, ]),
                    code = as.numeric(est[5, ]),
                    sumCFU = as.numeric(est[6, ]),
                    maxCFU = as.numeric(est[7, ]),
                    ignoreAboveMaxCFU = as.numeric(est[8, ]))
  l <- res$code == -2
  if (any(l)) {
    warning(paste("Could not estimate load for", sum(l),
                  "sample(s). Check samples with code=-2!"))
  }
  return(res)
}
