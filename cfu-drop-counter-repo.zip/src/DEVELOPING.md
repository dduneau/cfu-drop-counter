# Developing CFU Drop Counter

The app that people use is `../index.html`: one self-contained file, built from the sources in this folder. Change the sources, rebuild, and run the tests. Don't edit `index.html` by hand.

## Files

| File | What it holds |
|---|---|
| `app.src.html` | The page: layout, styles and all the app logic (setup, grid, counting, export, plates on the device, Load tab). |
| `detect.js` | Colony detection: grey level, plate-level threshold (Otsu), distance transform, colony splitting. For light scans (dark colonies on light agar), `flattenDark` turns each drop into darkness below its own background, and `detect` with `dark: true` drops soft-edged smudges, large dark masses and points on thin arcs (bubble edges, the rim). No dependencies; runs in the browser and in node. |
| `load.js` | Per-fly load estimation: the estimator itself, plus reading counts and layout files, joining, checks and the per-fly table. Runs in the browser and in node. |
| `method/` | The Method tab: `method.md` (text), `loadEstimate.R` (the reference estimator, shown in full) and `reproduce_example.R`. The R files are shown exactly as stored. |
| `build.py` | Assembles `../index.html` from the above, `../README.md` (shown in the Help tab) and `assets/`. |
| `assets/` | The example scan (the transmitted-light plate of `tests/data/COUNTS_light_manual.csv`, reduced to 2400 px wide) and the Home Screen icon. The earlier example, a reflected-light scan, is kept as `tests/data/sample_old.jpg` for the tests that load it as a file. |
| `tests/` | Browser tests (Playwright) and their data. Outputs go to `tests/out/`. |
| `validation/` | Checks of `load.js` against the reference R implementation, run in R through webR. The reference is `method/loadEstimate.R`, the same file the Method tab shows. |

## Setup

You need Node.js 18 or later and Python 3.

```
cd src
npm install                 # Playwright and webR
npx playwright install chromium
pip install markdown
```

## Build

```
python3 build.py            # writes ../index.html
```

## Test

```
npm test                    # all browser tests, against ../index.html
npm run validate            # the estimator against R (takes a few minutes)
```

The tests print their results instead of passing or failing silently. These are the lines to read:

- **counting**:
  - `in-app MAE` should be about 1.5, with about 62 of 79 drops within ±2. This is detection on `tests/data/scan.jpg`, compared with the manual counts in `COUNTS_25-06-17_1_plate01.csv`.
  - `CSV identical: true` means the counts file matches that reference file byte for byte.
  - `example scan vs hand counts`: detection on the example scan against the hand counts, about 75 of 80 drops within ±2.
- **light_scan**: on `tests/data/scan_light.jpg` (a transmitted-light scan at half resolution), the scan type is recognised as `light`, Snap puts the corners within about 2 px, and the counts are compared with the hand counts in `tests/data/COUNTS_light_manual.csv`: 77 of 80 drops with 30 colonies or fewer within ±2, mean error about 0.6. Run it with `SCAN=<full-resolution file>` to check that a large scan, which the app reduces to about 300 px between drops, gives the same counts.
- **progress_file**, **plates**: `restored identical: true`.
- **load_tab**: 8 flies detected, the duplicate plate blocked, and settings kept after a reload.
- **dilution**: the two empty columns give `NaN`, and are exported as `NA`.
- **ceiling_simulation**: compares the three ceiling options on simulated flies.
- **validation**:
  - `code mismatches 0`, and discrepancies around 10⁻¹² or smaller.
  - In the "ignore" setting the standard error can differ at the 10⁻⁹ level, which is expected.

Run the validation again after any change to `load.js` or to the files in `method/`. `r_example_vs_app` checks that the R example in the Method tab gives the same per-fly table as the app.

## Change the version

The version number is `APP_VERSION` near the top of the script in `app.src.html`, and the first line of `../README.md`. Change both, rebuild, and run the tests.

## Notes for changes

- **Saved data on users' devices.** Plates are kept in the browser's IndexedDB under the keys `plates`, `current`, `st:<id>` (plate state), `hist:<id>` (its undo/redo history), `img:<id>` (scan) and `load`. If you change their shape, add a one-time update at start-up, as the existing code does for older versions. Users must not lose plates when `index.html` is replaced.
- **The counts file format** (`buildCSV` in `app.src.html`) is used by the Load tab and by analyses outside the app. `tests/counting.js` checks it byte for byte.
- **`load.js` follows the reference R code line by line.** That includes R's root finder (`uniroot`, `extendInt = "downX"`), R's `dpois` method and compensated sums, which is why it agrees with R to about 10⁻¹². Keep that structure if you change it.
- **The Help tab** is `../README.md`, converted at build time. Update the README when behaviour changes.
