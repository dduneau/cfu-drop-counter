const path = require('path');
const APP = 'file://' + path.resolve(__dirname, '../../index.html');
const D = (f) => path.resolve(__dirname, 'data', f), O = (f) => path.resolve(__dirname, 'out', f);
const SAMPLE = path.resolve(__dirname, '../assets/sample.jpg');
const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch(); const p = await (await b.newContext()).newPage(); const errs = []; p.on('pageerror', (e) => errs.push(e.message));
  await p.goto(APP); await p.waitForTimeout(300);
  await p.click('#btn-sample'); await p.waitForTimeout(700);
  await p.click('#adv summary'); await p.click('#dilmode button[data-m="col"]');
  const f = [1, 10, 100, 5, 25, 125, 3, 9, 27, 81, '', ''];
  for (let k = 0; k < 12; k++) await p.fill(`[data-dil="${k}"]`, String(f[k]));
  await p.click('#to-grid'); await p.waitForTimeout(200); await p.click('[data-view=\"tune\"]'); await p.click('#detect-all'); await p.waitForFunction(() => S.view === 'count', null, { timeout: 60000 });
  console.log('dilutions A1..A12:', await p.evaluate(() => Array.from({ length: 12 }, (_, i) => dilutionFor(i)).join(' ')));
  console.log('CSV A11 row:', await p.evaluate(() => buildCSV().split('\r\n').find((l) => l.includes(';A11;'))));
  await p.click('[data-view="load"]'); await p.waitForTimeout(500); await p.setInputFiles('#l-layout', D('layout_rows.csv')); await p.waitForTimeout(600);
  console.log('load:', JSON.stringify(await p.evaluate(() => ({ spots: loadRes.res.flies[0].Spots, left: loadRes.res.tables.dropped.find((d) => d.Reason === 'No dilution set').Spots, warn: loadRes.res.warnings.map((w) => w.text) }))));
  // the COUNTS file read back in the Load tab gives the same
  const csv = await p.evaluate(() => buildCSV());
  require('fs').writeFileSync(O('dil_counts.csv'), csv);
  console.log('errors', errs); await b.close();
})();
