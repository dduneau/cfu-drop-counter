// Tune: sample drops with live preview; plate-wide runs spare checked drops; Count re-detects one drop only.
const path = require('path');
const APP = 'file://' + path.resolve(__dirname, '../../index.html');
const D = (f) => path.resolve(__dirname, 'data', f), O = (f) => path.resolve(__dirname, 'out', f);
const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch(); const errs = [];
  for (const [w, h, tag] of [[1180, 820, 'ipad'], [820, 1180, 'portrait']]) {
    const p = await (await b.newContext({ viewport: { width: w, height: h } })).newPage(); p.on('pageerror', (e) => errs.push(e.message));
    await p.goto(APP); await p.waitForTimeout(300);
    await p.setInputFiles('#file', D('scan.jpg')); await p.waitForFunction(() => !document.querySelector('#to-grid').disabled);
    await p.click('#to-grid'); await p.evaluate(() => { S.grid.c = [[346, 325], [2683, 329], [340, 1784], [2679, 1785]]; drawGrid(); });
    console.log(tag, '| grid side has no detection buttons:', await p.evaluate(() => !document.querySelector('#v-grid #detect-all') && !document.querySelector('#v-grid #manual-only')));
    let t = Date.now(); await p.click('#to-tune'); await p.waitForFunction(() => document.querySelectorAll('#t-grid .tile span').length === 8 && [...document.querySelectorAll('#t-grid .tile span')].every((s) => s.textContent), null, { timeout: 30000 });
    console.log(tag, '| tune ready in', Date.now() - t, 'ms | tiles:', (await p.$$eval('#t-grid .tile span', (e) => e.map((x) => x.textContent))).join(', '));
    await p.screenshot({ path: O(`tune-${tag}.png`) });
    if (tag !== 'ipad') continue;
    // sensitivity changes the preview at once
    const before = await p.$$eval('#t-grid .tile span', (e) => e.map((x) => x.textContent).join());
    await p.evaluate(() => { const e = document.querySelector('#sens'); e.value = 0.6; e.dispatchEvent(new Event('input')); }); await p.waitForTimeout(600);
    console.log('sensitivity +0.6 changes the preview:', before !== (await p.$$eval('#t-grid .tile span', (e) => e.map((x) => x.textContent).join())));
    // rapid image changes: the calibration ends up matching the final settings
    for (const v of [0.2, 0.5, 0.9, 0.3]) await p.evaluate((v) => { const e = document.querySelector('#img-c'); e.value = v; e.dispatchEvent(new Event('input')); }, v);
    await p.waitForTimeout(1500);
    const guard = await p.evaluate(async () => { const kept = JSON.stringify(await ensureCal()); invalidateCal(); const fresh = JSON.stringify(await ensureCal()); return kept === fresh; });
    console.log('calibration after rapid changes matches a fresh one:', guard);
    await p.evaluate(() => { for (const [id, v] of [['#img-c', 0], ['#sens', 0]]) { const e = document.querySelector(id); e.value = v; e.dispatchEvent(new Event('input')); } }); await p.waitForTimeout(800);
    // first run
    console.log('button before any count:', await p.textContent('#detect-all'), '| replace-all hidden:', await p.evaluate(() => document.querySelector('#t-all').hidden));
    await p.click('#detect-all'); await p.waitForFunction(() => S.view === 'count', null, { timeout: 60000 });
    // check 5 drops and correct one by hand
    for (let k = 0; k < 4; k++) await p.click('#c-next2');
    const box = await p.locator('#c-canvas').boundingBox(); await p.mouse.click(box.x + box.width / 2 + 160, box.y + box.height / 2 + 160);
    const checked = await p.evaluate(() => Object.fromEntries(Object.entries(S.wells).filter(([, w]) => w.seen || w.edited).map(([k, w]) => [k, JSON.stringify(w.m)])));
    console.log('checked drops:', Object.keys(checked).join(' '));
    // Count: no plate-wide buttons; this-drop sliders reset on the next drop; one drop changes
    console.log('count has no Row/Column/Plate buttons:', await p.evaluate(() => !document.querySelector('[data-redo]')));
    await p.evaluate(() => { const e = document.querySelector('#d-sens'); e.value = 0.8; e.dispatchEvent(new Event('input')); });
    const others = await p.evaluate(() => JSON.stringify(Object.fromEntries(Object.entries(S.wells).filter(([k]) => k !== wellName(S.cur)))));
    await p.click('#d-redo'); await p.waitForTimeout(800);
    console.log('this-drop re-detect leaves the other drops alone:', others === (await p.evaluate(() => JSON.stringify(Object.fromEntries(Object.entries(S.wells).filter(([k]) => k !== wellName(S.cur)))))), '| plate sensitivity unchanged:', await p.evaluate(() => S.det.sens));
    await p.click('#c-next2'); console.log('slider back to the plate value on the next drop:', await p.inputValue('#d-sens'));
    // Tune again: only unchecked drops are re-detected
    await p.click('[data-view="tune"]'); await p.waitForTimeout(800);
    console.log('button now:', await p.textContent('#detect-all'), '| replace-all shown:', await p.evaluate(() => !document.querySelector('#t-all').hidden));
    await p.evaluate(() => { const e = document.querySelector('#sens'); e.value = 0.5; e.dispatchEvent(new Event('input')); }); await p.waitForTimeout(500);
    const unBefore = await p.evaluate(() => JSON.stringify(Object.fromEntries(Object.entries(S.wells).filter(([, w]) => !(w.seen || w.edited)).map(([k, w]) => [k, w.m]))));
    const checkedNow = await p.evaluate(() => Object.fromEntries(Object.entries(S.wells).filter(([, w]) => w.seen || w.edited).map(([k, w]) => [k, JSON.stringify(w.m)])));
    await p.click('#detect-all'); await p.waitForFunction(() => S.view === 'count', null, { timeout: 60000 });
    const after = await p.evaluate(() => Object.fromEntries(Object.entries(S.wells).map(([k, w]) => [k, JSON.stringify(w.m)])));
    console.log('checked drops kept exactly:', Object.keys(checkedNow).every((k) => checkedNow[k] === after[k]), '| unchecked drops re-detected:', unBefore !== (await p.evaluate((ck) => JSON.stringify(Object.fromEntries(Object.entries(S.wells).filter(([k]) => !ck[k]).map(([k, w]) => [k, w.m]))), checkedNow)));
    await p.click('#c-undo'); console.log('one Undo restores their marks:', unBefore === (await p.evaluate((ck) => JSON.stringify(Object.fromEntries(Object.entries(S.wells).filter(([k]) => !ck[k]).map(([k, w]) => [k, w.m]))), checkedNow)));
    // replace every drop needs a confirmation
    await p.click('[data-view="tune"]'); await p.waitForTimeout(500); await p.click('#t-all');
    console.log('confirmation shown:', await p.evaluate(() => !document.querySelector('#t-all-confirm').hidden)); await p.click('#t-all-no');
    console.log('cancel keeps everything:', JSON.stringify(after) !== '' && (await p.evaluate(() => S.view)) === 'tune');
    // tapping a tile opens that drop
    const ti = await p.$eval('#t-grid .tile', (e) => +e.dataset.i); await p.click('#t-grid .tile');
    console.log('tile opens its drop in Count:', await p.evaluate((ti) => S.view === 'count' && S.cur === ti, ti));
  }
  console.log('errors', errs); await b.close();
})();
