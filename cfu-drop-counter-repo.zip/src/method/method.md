# Method

This tab describes how the Load step estimates the bacterial load of each fly. It gives the R code that defines the estimator, and an R example that reproduces the app's per-fly table.

## Model

Each fly's homogenate is plated as drops at several dilutions. For drop *i* of a fly, let *v*ᵢ be the volume plated (µL) and *d*ᵢ the dilution as a fraction (1 = undiluted, 1/25 = diluted 25-fold).

The number of colonies *y*ᵢ in the drop is modelled as **Poisson**, with mean

  *μ*ᵢ = *λ* · *v*ᵢ · *d*ᵢ

Here *λ* is the load per µL of homogenate, the one unknown for that fly. Drops are assumed independent.

## Which drops enter the estimate

- Drops marked **Ignore drop** (`NA` in the counts file) are left out.
- Drops in a row or column marked as not plated (dilution `NA`) are left out.
- Drops marked **Too many** (`Inf`) are treated as above the ceiling.
- Dilutions are entered as factors (10 = 1/10). A factor of 1 or less is treated as undiluted, and the app warns about factors between 0 and 1.

## Drops above the ceiling

Colonies merge in crowded drops, so counts above a ceiling *M* (30 by default) are not read as exact. The setting **Drops with more colonies than can be read** decides what such a drop contributes to the likelihood:

| Setting | A drop with *y*ᵢ ≤ *M* contributes | A drop above *M*, or too many to count, contributes | Model |
|---|---|---|---|
| Keep them as counts known to exceed the ceiling (**default**) | P(*Y* = *y*ᵢ) | P(*Y* > *M*) | Censored Poisson |
| Leave them out, and correct the rest for the ceiling | P(*Y* = *y*ᵢ) / P(*Y* ≤ *M*) | nothing (left out) | Right-truncated Poisson |
| No ceiling | P(*Y* = *y*ᵢ) for every finite count | nothing (drops marked too many to count are left out) | Poisson |

Each probability is that of a Poisson variable *Y* with mean *μ*ᵢ. In R's function the first two settings are `ignoreAboveMaxCFU = FALSE` and `ignoreAboveMaxCFU = TRUE`, with `maxCFU` = *M*; the third is `maxCFU = NA`.

## Estimate and standard error

- **The estimate.** *λ̂* maximises the log-likelihood over all the fly's drops. It is found as the root of the score with respect to log *λ*, using R's `uniroot` with the interval extended as needed.
- **The standard error of log *λ̂*.** It is 1 / √(−ℓ″), where ℓ″ is the second derivative of the log-likelihood with respect to log *λ*, taken at the estimate (the observed information). It is reported on the log scale chosen (log10 or log2).
- **The load per fly** is *λ̂* × *V*, where *V* is the homogenate volume per fly (250 µL by default).
- **The detection limit per fly** is *V* / Σ *v*ᵢ *d*ᵢ, summed over all of that fly's drops. It is the load implied by a single colony over everything plated for that fly. It is not the load at which detection becomes reliable.

## Status of each fly

- **Detected**: a load was estimated.
- **Not detected**: no colony on any drop of the fly, so no load could be estimated.
- **Above the dilutions used**: no drop was countable, so the load is higher than the series can measure.
- **Estimation failed**: colonies were counted, but the estimator found no estimate.

## Assumptions to keep in mind

- **The standard error assumes pure Poisson variation between drops.** Extra variation, from pipetting or clumped bacteria, makes the real uncertainty larger than this standard error.
- **Counts at or below the ceiling are taken as exact.** If crowded drops near the ceiling are undercounted, the estimate inherits that error. A lower ceiling limits it.

## Why drops above the ceiling are kept by default

The two ways of handling the ceiling were compared on simulated flies of known load, using the lab's design:

- One fly per row, 10 drops of 5 µL at dilutions 1, 1/10, 1/100, 1/5, 1/25, 1/125, 1/3, 1/9, 1/27 and 1/81.
- A ceiling of 30 and a homogenate of 250 µL.
- Counts drawn from the Poisson model. Drops above 300 colonies were recorded as too many to count.
- 2,000 flies at each true load, each estimated both ways.

The error is the estimated minus the true load, in log10 CFU per fly. The table gives the typical size of the error (root mean square):

| True load (CFU per fly) | Keep them (default) | Leave them out |
|---|---|---|
| 10³ | 0.069 | 0.072 |
| 10⁴ | 0.057 | 0.074 |
| 10⁴·⁵ | 0.051 | 0.060 |
| 10⁵ | 0.053 | 0.056 |

Over this range both settings are unbiased to within about 0.02 log10. Keeping the drops above the ceiling gives errors as small or smaller, because every drop contributes.

**Near the top of the measurable range, the two settings differ sharply.**

- At 10⁵·² CFU per fly, about 4 flies in 10 have a single countable drop.
- In a run of 4,000 flies at that load, leaving the drops above the ceiling out gave an estimate more than 10 times too high for 2% of the flies estimated (86 of 3,746), and more than twice too high for 6% (216). Keeping them never did.
- The reason: when the drops above the ceiling are left out, the one remaining count is treated as a count *known to be at most 30*. A count of, say, 25 under that condition fits a very high load almost as well as the true one. When the drops are kept, the 25 is an ordinary count, and the drops above the ceiling add that the load is high. Together they pin the load down.

Above about 10⁵·⁴ CFU per fly, most flies have no countable drop at all. Both settings then report them as *Above the dilutions used*.

**What keeping them costs.** It takes the counts just below the ceiling at face value. When crowded drops were made to undercount by about 15% at 30 colonies, keeping them gave a bias of −0.07 log10 at 10⁴ CFU per fly, against −0.05 for leaving them out. A lower ceiling reduces this.

Both simulations, the comparison over loads and the run near the top of the range, are part of the app's source code (`tests/ceiling_simulation.js`), so they can be rerun or adapted to another design.

## The estimator in R

The app runs a JavaScript translation of the two R functions below, line by line, including R's root finder and its Poisson probability functions. The translation was checked against this R code, run in R 4.6:

- On 1,415 simulated samples under every setting, the two agree to about 10⁻¹² and succeed or fail on the same samples.
- On a 48-fly, 8-plate data set, counts, statuses and detection limits are identical, and the loads agree to 10⁻¹³.

<!--RFUNC-->

## Reproducing the per-fly table in R

With the functions above loaded, this reads a counts file saved by the app and a layout file, and gives the same loads, standard errors and detection limits as the Load step, to about 10⁻¹².

<!--REXAMPLE-->
