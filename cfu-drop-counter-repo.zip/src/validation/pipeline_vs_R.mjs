import path from 'path'; import { fileURLToPath } from 'url';
const HERE = path.dirname(fileURLToPath(import.meta.url));
const WEBR = path.resolve(HERE, '../node_modules/webr/dist') + '/';
const DATA = (f) => path.resolve(HERE, 'data', f);
const REF_R = path.resolve(HERE, '../method/loadEstimate.R');
const LOADJS = path.resolve(HERE, '../load.js');
import { WebR } from 'webr'; import fs from 'fs'; import { createRequire } from 'module';
const L = createRequire(import.meta.url)(LOADJS);
const lay = L.buildLayout(L.parseTable(fs.readFileSync(DATA('plate_layout_example.csv'), 'utf8')), 8, 12);
const settingsList = [{ mode: 'ignore', maxCFU: 50 }, { mode: 'censor', maxCFU: 50 }, { mode: 'none', maxCFU: 50 }, { mode: 'ignore', maxCFU: 30 }];
const webR = new WebR({ baseUrl: WEBR, interactive: false }); await webR.init();
await webR.FS.writeFile('/tmp/le.R', fs.readFileSync(REF_R)); await webR.FS.writeFile('/tmp/lay.csv', fs.readFileSync(DATA('plate_layout_example.csv'))); await webR.FS.writeFile('/tmp/cnt.csv', fs.readFileSync(DATA('plate_counts_example.csv')));
for (const st of settingsList) {
  const { spots } = L.spotsFromTable(L.parseTable(fs.readFileSync(DATA('plate_counts_example.csv'), 'utf8')), 'cnt.csv', 'CFU', 5);
  const res = L.analyse(spots, lay, { ...st, logbase: 10, homog: 250, dupAction: 'keep' });
  const mx = st.mode === 'none' ? 'NA' : st.maxCFU, ig = st.mode === 'ignore' ? 'TRUE' : 'FALSE';
  const out = await webR.evalRString(`
    source('/tmp/le.R')
    l <- read.table('/tmp/lay.csv', header=TRUE, sep=';', stringsAsFactors=FALSE)
    s <- read.table('/tmp/cnt.csv', header=TRUE, sep=';', stringsAsFactors=FALSE)
    key <- function(x) as.character(as.integer(gsub('[^0-9]','',x)))
    l$plate <- key(l$Plate); s$plate <- key(s$Plate)
    s$CFU <- as.numeric(s$CFU); s$dil_frac <- ifelse(s$Dilution <= 1, 1, 1/s$Dilution)
    m <- merge(l[,c('plate','WELL','ID')], s, by=c('plate','WELL'))
    d <- m[!is.na(m$CFU) & !is.na(m$dil_frac) & !is.na(m$Volume),]
    mx <- ${mx}
    e <- loadEstimate(cfu=d$CFU, dilution=d$dil_frac, volume=d$Volume, sampleID=as.character(d$ID), maxCFU=mx, ignoreAboveMaxCFU=${ig}, logbase=10)
    cls <- ifelse(!is.finite(d$CFU), 'tm', ifelse(!is.na(mx) & d$CFU > mx, 'ab', 'ct'))
    pf <- do.call(rbind, lapply(split(seq_len(nrow(d)), d$ID), function(i) data.frame(ID=d$ID[i[1]], Spots=length(i), Countable=sum(cls[i]=='ct'), Above=sum(cls[i]=='ab'), TooMany=sum(cls[i]=='tm'), Total=sum(d$CFU[i][is.finite(d$CFU[i])]), LOD=250/sum(d$dil_frac[i]*d$Volume[i]))))
    o <- merge(pf, data.frame(ID=e$sampleID, load=e$load, logload=e$logload, se=e$se.logload, code=e$code), by='ID')
    o$CFU <- o$load*250
    o$Status <- ifelse(!is.na(o$CFU), 'Detected', ifelse(o$Countable==0, 'Above the dilutions used', ifelse(o$Total==0, 'Not detected', 'Estimation failed')))
    o[] <- lapply(o, function(x) if (is.numeric(x)) sprintf('%.17g', x) else x)
    paste(apply(o, 1, function(r) paste(trimws(r), collapse='|')), collapse='\\n')`);
  const R = Object.fromEntries(out.split('\n').map((l) => { const f = l.split('|'); return [f[0], f]; }));
  let worst = 0, mism = 0, n = 0;
  for (const f of res.flies) {
    const r = R[f.ID]; n++;
    const ints = [f.Spots, f.Countable, f.Above_ceiling, f.Too_many, f.Total_CFU].map(String), rints = r.slice(1, 6).map((x) => String(+x));
    if (ints.join() !== rints.join() || f.Status !== r[12] || f.code !== +r[10]) { mism++; console.log('mismatch', f.ID, ints, rints, f.Status, r[12]); }
    for (const [a, b] of [[f.LOD_per_fly, +r[6]], [f.load, +r[7]], [f.logload, +r[8]], [f['se.logload'], +r[9]]]) {
      if (isNaN(a) && isNaN(b)) continue; worst = Math.max(worst, Math.abs(a - b) / Math.max(1e-12, Math.abs(b)));
    }
  }
  const tally = res.flies.reduce((a, f) => ((a[f.Status] = (a[f.Status] || 0) + 1), a), {});
  console.log(st.mode, st.maxCFU, '| flies JS', res.flies.length, 'R', Object.keys(R).length, '| mismatches', mism, '| worst rel diff', worst.toExponential(2), '|', JSON.stringify(tally), '| match', res.match, '| blocking', res.blocking.length, '| warnings', res.warnings.map((w) => w.text.slice(0, 60)));
}
webR.close(); process.exit(0);
