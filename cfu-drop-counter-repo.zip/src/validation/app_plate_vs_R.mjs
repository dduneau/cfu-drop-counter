import path from 'path'; import { fileURLToPath } from 'url';
const HERE = path.dirname(fileURLToPath(import.meta.url));
const WEBR = path.resolve(HERE, '../node_modules/webr/dist') + '/';
const DATA = (f) => path.resolve(HERE, 'data', f);
const REF_R = path.resolve(HERE, '../method/loadEstimate.R');
const LOADJS = path.resolve(HERE, '../load.js');
import { WebR } from 'webr'; import fs from 'fs'; import { createRequire } from 'module';
const webR = new WebR({ baseUrl: WEBR, interactive: false }); await webR.init();
await webR.FS.writeFile('/tmp/le.R', fs.readFileSync(REF_R)); for (const f of ['plateA_counts.csv', 'layout_rows.csv']) await webR.FS.writeFile('/tmp/' + f, fs.readFileSync(DATA(f)));
const LE = createRequire(import.meta.url)(LOADJS);
const lay = LE.buildLayout(LE.parseTable(fs.readFileSync(DATA('layout_rows.csv'), 'utf8')), 8, 12);
const jsFlies = (mode) => { const { spots } = LE.spotsFromTable(LE.parseTable(fs.readFileSync(DATA('plateA_counts.csv'), 'utf8')), 'plateA_counts.csv', 'Prett', 5); return LE.analyse(spots, lay, { mode, maxCFU: 50, logbase: 10, homog: 250, dupAction: 'keep' }).flies; };
for (const mode of ['ignore', 'censor']) {
  const out = await webR.evalRString(`
    source('/tmp/le.R')
    s <- read.table('/tmp/plateA_counts.csv', header=TRUE, sep=';', stringsAsFactors=FALSE)
    l <- read.table('/tmp/layout_rows.csv', header=TRUE, sep=';', stringsAsFactors=FALSE)
    s$row <- substr(s$WELL, 1, 1)
    m <- merge(l, s, by.x='ROW', by.y='row')
    m$CFU <- as.numeric(m$Prett); m$dil <- ifelse(m$Dilution <= 1, 1, 1/m$Dilution)
    d <- m[!is.na(m$CFU) & !is.na(m$dil) & !is.na(m$Volume),]; d <- d[order(d$WELL, method='radix'),]
    e <- loadEstimate(cfu=d$CFU, dilution=d$dil, volume=d$Volume, sampleID=d$ID, maxCFU=50, ignoreAboveMaxCFU=${mode === 'ignore' ? 'TRUE' : 'FALSE'}, logbase=10)
    lod <- tapply(250/ ave(d$dil*d$Volume, d$ID, FUN=sum), d$ID, function(x) x[1])
    paste(sprintf('%s|%.17g|%.17g|%.17g|%d|%.17g', e$sampleID, e$logload, e$se.logload, e$load, sapply(e$sampleID, function(i) sum(d$ID==i)), lod[e$sampleID]), collapse='\\n')`);
  const R = Object.fromEntries(out.split('\n').map((l) => { const f = l.split('|'); return [f[0], f.slice(1).map(Number)]; }));
  const J = jsFlies(mode);
  let worst = 0, bad = 0;
  for (const f of J) { const r = R[f.ID]; if (r[3] !== f.Spots) bad++; const ds = [[f.logload, r[0]], [f['se.logload'], r[1]], [f.load, r[2]], [f.LOD_per_fly, r[4]]].map(([a, b]) => Math.abs(a - b) / Math.abs(b)); if (Math.max(...ds) > 1e-11) console.log(mode, f.ID, ds.map((x) => x.toExponential(1)).join(' '), f.Countable, f.Above_ceiling, f.Too_many); worst = Math.max(worst, ...ds); }
  console.log(mode, 'flies', J.length, '| spot-count mismatches', bad, '| worst rel diff', worst.toExponential(2));
}
webR.close(); process.exit(0);
