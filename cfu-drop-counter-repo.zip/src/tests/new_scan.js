const path = require('path');
const APP = 'file://' + path.resolve(__dirname, '../../index.html');
const D = (f) => path.resolve(__dirname, 'data', f), O = (f) => path.resolve(__dirname, 'out', f);
const SAMPLE = path.resolve(__dirname, 'data', 'sample_old.jpg'); // the earlier example scan (reflected light)
const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch(); const p = await (await b.newContext()).newPage(); const errs = []; p.on('pageerror', (e) => errs.push(e.message));
  await p.goto(APP); await p.waitForTimeout(300);
  await p.click('#btn-sample'); await p.waitForTimeout(700); await p.click('#to-grid'); await p.waitForTimeout(200); await p.click('[data-view=\"tune\"]'); await p.click('#detect-all'); await p.waitForFunction(() => S.view === 'count', null, { timeout: 60000 });
  await p.click('[data-view="setup"]'); await p.setInputFiles('#file', D('scan.jpg')); await p.waitForTimeout(1200);
  console.log('choose scan with work in progress -> plates', await p.evaluate(() => PLATES.length), '| current scan', await p.evaluate(() => S.image.name), '| grid reset', await p.evaluate(() => S.grid === null));
  await p.setInputFiles('#file', SAMPLE); await p.waitForTimeout(1000);
  console.log('replace scan on a plate without work -> plates', await p.evaluate(() => PLATES.length), '| scan', await p.evaluate(() => S.image.name));
  console.log('errors', errs); await b.close();
})();
