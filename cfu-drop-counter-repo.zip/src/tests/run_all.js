// Runs every browser test against ../../index.html and prints each test's output.
// Build first (python3 build.py). Screenshots and saved files go to tests/out/.
const { execFileSync } = require('child_process');
const path = require('path'), fs = require('fs');
fs.mkdirSync(path.join(__dirname, 'out'), { recursive: true });
const tests = ['counting', 'progress_file', 'download', 'snap', 'plates', 'new_scan', 'dilution', 'file_names', 'one_type', 'version', 'hide_marks', 'undo_redo', 'format_lock', 'tune', 'image_view', 'method_tab', 'load_tab', 'load_defaults', 'ceiling_simulation'];
let failed = 0;
for (const t of tests) {
  process.stdout.write(`\n=== ${t}\n`);
  try { process.stdout.write(execFileSync('node', [path.join(__dirname, t + '.js')], { encoding: 'utf8', timeout: 600000 })); }
  catch (e) { failed++; process.stdout.write((e.stdout || '') + (e.stderr || e.message) + '\n'); }
}
console.log(`\n${tests.length - failed} of ${tests.length} test scripts ran without error. Read the lines above for the results.`);
process.exit(failed ? 1 : 0);
