// Light scans (transmitted light: dark colonies on light agar).
// Checks: the scan type is recognised, Snap finds the dark rims, detection runs on the
// whole plate, and the counts match the reference prototype run on the same scan.
// SCAN=/path/to/full-resolution.png node tests/light_scan.js  also checks a full-size scan
// (the app reduces it to ~300 px between drops, so counts should be the same).
const path = require('path');
const APP = 'file://' + path.resolve(__dirname, '../../index.html');
const SCAN = process.env.SCAN || path.resolve(__dirname, 'data', 'scan_light.jpg');
const { chromium } = require('playwright');
// detection on tests/data/scan_light.jpg (Surv_Prett_0_005_T0_exp1, half resolution), from the prototype
const REF = [47, 9, 3, 0, 0, 1, 17, 8, 4, 1, 0, 0, 29, 12, 6, 2, 2, 0, 14, 8, 3, 0, 0, 0, 44, 14, 7, 2, 1, 0, 17, 7, 6, 0, 1, 0, 41, 17, 8, 1, 0, 1, 22, 8, 2, 0, 1, 0, 53, 24, 6, 1, 2, 0, 27, 3, 3, 1, 0, 0, 71, 27, 14, 2, 2, 1, 27, 8, 0, 1, 0, 0, 144, 68, 31, 11, 1, 3, 84, 46, 7, 6, 13, 38, 202, 140, 69, 48, 7, 5, 153, 68, 29, 5, 10, 75];
const TRUE_CORNERS = [[330, 271], [3458, 256], [333, 2256], [3462, 2241]]; // A1, A12, H1, H12 at half resolution
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1180, height: 820 } });
  const errs = []; p.on('pageerror', (e) => errs.push(e.message));
  await p.goto(APP); await p.waitForTimeout(300);
  await p.setInputFiles('#file', SCAN); await p.waitForFunction(() => !document.querySelector('#to-grid').disabled, null, { timeout: 120000 });
  const info = await p.evaluate(() => ({ bg: S.bg, w: S.image.w, h: S.image.h }));
  const k = info.w / 3672; // corners above are for the half-resolution copy
  console.log('scan', path.basename(SCAN), info.w + '×' + info.h, '| scan type recognised as', info.bg);
  await p.click('#to-grid'); await p.waitForTimeout(200);
  // corners placed by hand, roughly (about a tenth of a well off), then Snap
  const rough = TRUE_CORNERS.map(([x, y], j) => [(x + [22, -18, 15, -25][j]) * k, (y + [-20, 16, 24, -14][j]) * k]);
  const snap = await p.evaluate((c) => { S.grid.c = c; const r = snapGrid(); if (r.ok) { S.grid.c = r.corners; invalidateCal(); } return r; }, rough);
  const err = Math.max(...snap.corners.map((c, j) => Math.hypot(c[0] / k - TRUE_CORNERS[j][0], c[1] / k - TRUE_CORNERS[j][1])));
  console.log('snap ok', snap.ok, 'resid', snap.resid.toFixed(3), '| worst corner off by', err.toFixed(1), 'px (half-res), drop spacing 286');
  const t = Date.now();
  const r = await p.evaluate(async () => { await detectWells(allWells(), '#t-prog'); return { n: allWells().map((i) => W(i).m.length), cal: S.cal }; });
  console.log('detection on 96 drops', ((Date.now() - t) / 1000).toFixed(1), 's | colony radius', r.cal.r0.toFixed(1), 'px at scale', r.cal.f.toFixed(2));
  let ae = 0, same = 0, big = [];
  r.n.forEach((v, i) => { const d = Math.abs(v - REF[i]); ae += d; if (d === 0) same++; if (d > Math.max(2, REF[i] * 0.1)) big.push(`${'ABCDEFGH'[(i / 12) | 0]}${(i % 12) + 1}: ${v} vs ${REF[i]}`); });
  for (let row = 0; row < 8; row++) console.log('ABCDEFGH'[row], r.n.slice(row * 12, row * 12 + 12).join('\t'));
  console.log('vs prototype: identical on', same, '/ 96, mean abs diff', (ae / 96).toFixed(2), big.length ? '| differ by >10%: ' + big.join(', ') : '');
  // the Tune preview and the scan-type switch
  await p.click('#to-tune'); await p.waitForTimeout(1500);
  const pressed = await p.evaluate(() => [...document.querySelectorAll('#bgmode button')].map((x) => x.dataset.bg + ':' + x.getAttribute('aria-pressed')).join(' '));
  console.log('Tune scan-type buttons', pressed);
  await p.screenshot({ path: path.resolve(__dirname, 'out', 'light_tune.png') });
  await p.click('#bgmode [data-bg="dark"]'); await p.waitForTimeout(300);
  const after = await p.evaluate(async () => { await ensureCal(); return { bg: S.bg, calBg: S.cal.bg }; });
  console.log('switched to', after.bg, '| calibration redone for', after.calBg);
  console.log('errors', errs);
  await b.close();
})();
