#!/usr/bin/env python3
"""Assemble index.html (the app, one self-contained file) from the sources.

    python3 build.py            -> writes ../index.html

Inputs (all in this folder unless noted):
  app.src.html      page, styles and app logic, with four placeholders
  detect.js         colony detection          -> /*DETECT*/
  load.js           per-fly load estimation   -> /*LOADEST*/
  ../README.md      user guide, shown in the Help tab -> /*HELP*/
  assets/sample.jpg example scan              -> /*SAMPLE*/
  assets/icon180.png Home Screen icon
Requires: pip install markdown
"""
import base64, os, markdown

here = os.path.dirname(os.path.abspath(__file__))
p = lambda *a: os.path.join(here, *a)

page = open(p("app.src.html"), encoding="utf-8").read()
help_html = markdown.markdown(open(p("..", "README.md"), encoding="utf-8").read(), extensions=["tables", "fenced_code"])
page = (page.replace("/*HELP*/", help_html, 1)
            .replace("/*DETECT*/", open(p("detect.js"), encoding="utf-8").read(), 1)
            .replace("/*LOADEST*/", open(p("load.js"), encoding="utf-8").read(), 1)
            .replace("/*SAMPLE*/", base64.b64encode(open(p("assets", "sample.jpg"), "rb").read()).decode(), 1))
icon = base64.b64encode(open(p("assets", "icon180.png"), "rb").read()).decode()
head = ('<!doctype html><html><head><meta charset=utf-8>'
        '<meta name=viewport content="width=device-width,initial-scale=1,viewport-fit=cover">'
        '<meta name="apple-mobile-web-app-capable" content="yes"><meta name="mobile-web-app-capable" content="yes">'
        '<meta name="apple-mobile-web-app-title" content="CFU Counter"><meta name="apple-mobile-web-app-status-bar-style" content="default">'
        f'<link rel="apple-touch-icon" href="data:image/png;base64,{icon}"></head><body>')
out = p("..", "index.html")
open(out, "w", encoding="utf-8").write(head + page + "</body></html>")
print(f"wrote {out} ({os.path.getsize(out) // 1024} kB)")
