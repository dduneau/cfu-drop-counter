const path = require('path');
const APP = 'file://' + path.resolve(__dirname, '../../index.html');
const D = (f) => path.resolve(__dirname, 'data', f), O = (f) => path.resolve(__dirname, 'out', f);
const SAMPLE = path.resolve(__dirname, 'data', 'sample_old.jpg'); // the earlier example scan (reflected light)
const { chromium } = require('playwright'); const fs=require('fs');
(async () => {
  const b = await chromium.launch(); const ctx = await b.newContext({ acceptDownloads: true, viewport:{width:1180,height:820} });
  const p = await ctx.newPage(); const errs=[]; p.on('pageerror',e=>errs.push(e.message));
  await p.goto(APP); await p.waitForTimeout(300);
  await p.setInputFiles('#file',D('scan.jpg')); await p.waitForFunction(()=>!document.querySelector('#to-grid').disabled);
  await p.fill('[data-f="0"][data-k="value"]','25-06-17'); await p.fill('[data-f="2"][data-k="value"]','Traj_plate01');
  await p.click('#to-grid'); await p.evaluate(()=>{S.grid.c=[[346,325],[2683,329],[340,1784],[2679,1785]];});
  await p.click('[data-view=\"tune\"]'); await p.click('#detect-all'); await p.waitForFunction(()=>S.view==='count',null,{timeout:60000});
  // edit a few drops
  for (let k=0;k<5;k++) await p.click('#c-next2');
  const box=await p.locator('#c-canvas').boundingBox(); await p.mouse.click(box.x+box.width/2+140, box.y+box.height/2+140);
  await p.click('#f-ign');
  const before = await p.evaluate(()=>JSON.stringify({w:S.wells,cur:S.cur,grid:S.grid}));
  const csvBefore = await p.evaluate(()=>buildCSV());
  const [d] = await Promise.all([p.waitForEvent('download'), p.click('#c-progress')]);
  const pfile=O('saved-progress.json'); await d.saveAs(pfile); console.log('saved', d.suggestedFilename(), fs.statSync(pfile).size,'bytes');
  // fresh browser: progress first, then scan
  const ctx2 = await b.newContext({ viewport:{width:1180,height:820} }); const q=await ctx2.newPage(); q.on('pageerror',e=>errs.push(e.message));
  await q.goto(APP); await q.waitForTimeout(300);
  await q.setInputFiles('#pfile', pfile); await q.waitForTimeout(200); console.log('prompt:', await q.textContent('#prog-info'));
  await q.setInputFiles('#file', SAMPLE); await q.waitForTimeout(500); console.log('wrong scan:', (await q.textContent('#prog-info')).slice(0,80));
  await q.setInputFiles('#file', D('scan.jpg')); await q.waitForFunction(()=>S.view==='count',null,{timeout:10000});
  const after = await q.evaluate(()=>JSON.stringify({w:S.wells,cur:S.cur,grid:S.grid}));
  console.log('state restored identical:', before===after, 'csv identical:', csvBefore===await q.evaluate(()=>buildCSV()), 'cur', await q.evaluate(()=>wellName(S.cur)));
  await q.screenshot({path:O('shot-reopen.png')});
  // scan first then progress
  const ctx3 = await b.newContext(); const r=await ctx3.newPage(); await r.goto(APP); await r.waitForTimeout(300);
  await r.setInputFiles('#file',D('scan.jpg')); await r.waitForTimeout(500); await r.setInputFiles('#pfile', pfile); await r.waitForFunction(()=>S.view==='count',null,{timeout:10000});
  console.log('scan-then-progress csv identical:', csvBefore===await r.evaluate(()=>buildCSV()));
  // bad file
  fs.writeFileSync(O('bad.json'),'{"x":1}'); await r.click('[data-view="setup"]'); await r.setInputFiles('#pfile',O('bad.json')); await r.waitForTimeout(200); console.log('bad:', await r.textContent('#prog-info'));
  console.log('errors', errs); await b.close();
})();
