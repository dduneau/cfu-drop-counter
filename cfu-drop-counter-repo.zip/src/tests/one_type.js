const path = require('path');
const APP = 'file://' + path.resolve(__dirname, '../../index.html');
const D = (f) => path.resolve(__dirname, 'data', f), O = (f) => path.resolve(__dirname, 'out', f);
const SAMPLE = path.resolve(__dirname, 'data', 'sample_old.jpg'); // the earlier example scan (reflected light)
const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch(); const p = await (await b.newContext({ viewport: { width: 1180, height: 820 } })).newPage(); const errs = []; p.on('pageerror', (e) => errs.push(e.message));
  await p.goto(APP); await p.waitForTimeout(300);
  console.log('types:', await p.evaluate(() => S.types.map((t) => t.name).join(',')));
  await p.click('#btn-sample'); await p.waitForTimeout(700); await p.click('#to-grid'); await p.waitForTimeout(200); await p.click('[data-view=\"tune\"]'); await p.click('#detect-all'); await p.waitForFunction(() => S.view === 'count', null, { timeout: 60000 });
  console.log('header:', await p.evaluate(() => buildCSV().split('\r\n')[0]), '| change-type switch hidden:', await p.evaluate(() => document.querySelector('#tapmode').parentElement.hidden));
  await p.screenshot({ path: O('onetype.png') });
  console.log('errors', errs); await b.close();
})();
