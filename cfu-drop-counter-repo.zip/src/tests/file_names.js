const path = require('path');
const APP = 'file://' + path.resolve(__dirname, '../../index.html');
const D = (f) => path.resolve(__dirname, 'data', f), O = (f) => path.resolve(__dirname, 'out', f);
const SAMPLE = path.resolve(__dirname, 'data', 'sample_old.jpg'); // the earlier example scan (reflected light)
const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch(); const p = await (await b.newContext({ acceptDownloads: true })).newPage(); const errs = []; p.on('pageerror', (e) => errs.push(e.message));
  await p.goto(APP); await p.waitForTimeout(300);
  await p.setInputFiles('#file', D('scan.jpg')); await p.waitForTimeout(800);
  await p.fill('[data-f="2"][data-k="value"]', 'Traj_plate01');
  await p.click('#to-grid'); await p.waitForTimeout(200); await p.click('[data-view=\"tune\"]'); await p.click('#manual-only'); await p.click('[data-view="export"]'); await p.waitForTimeout(200);
  console.log('one plate on the scan:', await p.inputValue('#x-name'), '|', await p.evaluate(() => progressName()));
  await p.click('#x-nextplate'); await p.waitForTimeout(400); await p.click('[data-view=\"tune\"]'); await p.click('#manual-only'); await p.click('[data-view="export"]'); await p.waitForTimeout(200);
  console.log('second plate, same name:', await p.inputValue('#x-name'));
  await p.evaluate(() => { S.fields[2].value = 'Traj_plate02'; save(); }); await p.click('[data-view="count"]'); await p.click('[data-view="export"]'); await p.waitForTimeout(200);
  console.log('second plate, own name:', await p.inputValue('#x-name'));
  const [d] = await Promise.all([p.waitForEvent('download'), p.click('#x-save')]); console.log('saved as', d.suggestedFilename());
  console.log('errors', errs); await b.close();
})();
