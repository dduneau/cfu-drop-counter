// Undo / Redo: taps, flags, re-detection, keyboard, branch rule, saved per plate across reloads.
const path = require('path');
const APP = 'file://' + path.resolve(__dirname, '../../index.html');
const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch(); const errs = [];
  const p = await (await b.newContext({ viewport: { width: 1180, height: 820 } })).newPage(); p.on('pageerror', (e) => errs.push(e.message));
  await p.goto(APP); await p.waitForTimeout(300);
  await p.click('#btn-sample'); await p.waitForTimeout(700); await p.click('#to-grid'); await p.waitForTimeout(200); await p.click('[data-view=\"tune\"]'); await p.click('#detect-all'); await p.waitForFunction(() => S.view === 'count', null, { timeout: 60000 });
  const n = () => p.evaluate(() => W(S.cur).m.length), st = () => p.evaluate(() => `undo ${undoStack.length}, redo ${redoStack.length}, buttons ${document.querySelector('#c-undo').disabled ? 'off' : 'on'}/${document.querySelector('#c-redo').disabled ? 'off' : 'on'}`);
  const box = await p.locator('#c-canvas').boundingBox(), cx = box.x + box.width / 2, cy = box.y + box.height / 2;
  const n0 = await n();
  await p.mouse.click(cx + 150, cy + 150); await p.mouse.click(cx - 150, cy + 150); await p.mouse.click(cx + 150, cy - 150);
  console.log('3 taps:', n0, '->', await n(), '|', await st());
  await p.click('#c-undo'); await p.click('#c-undo'); console.log('undo ×2:', await n(), '|', await st());
  await p.click('#c-redo'); console.log('redo ×1:', await n(), '|', await st());
  await p.keyboard.press('Control+z'); console.log('Ctrl+Z:', await n());
  await p.keyboard.press('Control+Shift+z'); console.log('Ctrl+Shift+Z:', await n());
  await p.keyboard.press('Control+y'); console.log('Ctrl+Y:', await n(), '|', await st());
  await p.click('#c-undo'); await p.mouse.click(cx - 150, cy - 150);
  console.log('new change after undo clears redo:', await st());
  await p.click('#f-empty'); console.log('Empty drop:', await n(), '| undo ->', (await p.click('#c-undo'), await n()), '| redo ->', (await p.click('#c-redo'), await n()));
  await p.click('#c-undo');
  // a re-detection of the whole plate is one step
  const before = await p.evaluate(() => JSON.stringify(S.wells));
  await p.evaluate(() => { S.det.sens = 0.4; }); await p.click('[data-view="tune"]'); await p.click('#t-all'); await p.click('#t-all-yes'); await p.waitForFunction(() => S.view === 'count', null, { timeout: 60000 }); await p.waitForTimeout(200);
  const changed = before !== (await p.evaluate(() => JSON.stringify(S.wells)));
  await p.click('#c-undo'); console.log('re-detect plate changed marks:', changed, '| one undo restores all 96 drops:', before === (await p.evaluate(() => JSON.stringify(S.wells))));
  // history survives a reload
  const hist = await st(); await p.waitForTimeout(300); await p.reload(); await p.waitForTimeout(1500); await p.click('[data-view="count"]'); await p.waitForTimeout(200);
  console.log('after reload:', await st(), '| was', hist);
  await p.click('#c-redo'); console.log('redo after reload works:', changed && before !== (await p.evaluate(() => JSON.stringify(S.wells))));
  // each plate keeps its own history
  const first = await p.evaluate(() => S.sid);
  await p.click('[data-view="export"]'); await p.click('#x-nextplate'); await p.waitForTimeout(400);
  console.log('new plate starts empty:', await st());
  await p.click('[data-view="setup"]'); await p.click(`[data-popen="${first}"]`); await p.waitForFunction((id) => S.sid === id, first); await p.click('[data-view="count"]'); await p.waitForTimeout(200);
  console.log('back on first plate:', await st());
  console.log('errors', errs); await b.close();
})();
