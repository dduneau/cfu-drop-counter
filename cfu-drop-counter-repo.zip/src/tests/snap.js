const path = require('path');
const APP = 'file://' + path.resolve(__dirname, '../../index.html');
const D = (f) => path.resolve(__dirname, 'data', f), O = (f) => path.resolve(__dirname, 'out', f);
const SAMPLE = path.resolve(__dirname, 'data', 'sample_old.jpg'); // the earlier example scan (reflected light)
const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1180, height: 820 } });
  p.on('pageerror', e => console.log('ERR', e.message));
  await p.goto(APP); await p.waitForTimeout(300);
  await p.setInputFiles('#file', D('scan.jpg')); await p.waitForFunction(() => !document.querySelector('#to-grid').disabled);
  await p.click('#to-grid'); await p.waitForTimeout(200);
  const tries = { top_off25: [[370,350],[2660,305],[320,1760],[2700,1810]], top_off80: [[420,400],[2600,260],[260,1700],[2750,1870]], bottom_off40: [[370,2350],[2620,2270],[290,3800],[2700,3730]], initial: null };
  for (const [k, c] of Object.entries(tries)) {
    await p.evaluate((c) => { if (c) S.grid.c = c; else { S.grid = null; ensureGrid(); } }, c);
    const t = Date.now(); const r = await p.evaluate(() => snapGrid()); 
    console.log(k, Date.now()-t, 'ms', JSON.stringify(r.corners.map(x=>x.map(Math.round))), 'resid', r.resid.toFixed(3));
  }
  await p.click('#btn-sample').catch(()=>{});
  await p.click('[data-view="setup"]'); await p.click('#btn-sample'); await p.waitForTimeout(800); await p.click('#to-grid'); await p.waitForTimeout(200);
  const r = await p.evaluate(() => snapGrid()); console.log('sample', JSON.stringify(r.corners.map(x=>x.map(Math.round))), r.resid.toFixed(3), 'expect ~', JSON.stringify([[216,177],[2260,167],[218,1475],[2263,1465]]));
  await b.close();
})();
