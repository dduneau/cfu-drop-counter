const path = require('path');
const APP = 'file://' + path.resolve(__dirname, '../../index.html');
const D = (f) => path.resolve(__dirname, 'data', f), O = (f) => path.resolve(__dirname, 'out', f);
const SAMPLE = path.resolve(__dirname, '../assets/sample.jpg');
const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch(); const errs = [];
  const p = await (await b.newContext()).newPage(); p.on('pageerror', (e) => errs.push(e.message));
  await p.goto(APP); await p.waitForTimeout(400);
  await p.click('[data-view="load"]'); await p.waitForTimeout(200);
  console.log('fresh:', await p.evaluate(() => [LOADST.mode, LOADST.maxCFU, document.querySelector('#l-max').value, document.querySelector('#l-mode input:checked').value].join(' ')));
  // an iPad with the old saved settings (ignore, 50)
  await p.evaluate(async () => { await DB.put('load', JSON.stringify({ files: [], layout: null, picked: {}, type: 'Prett', mode: 'ignore', maxCFU: 50, homog: 250, logbase: 10, dupAction: 'keep' })); });
  await p.reload(); await p.waitForTimeout(1200);
  console.log('old settings after update:', await p.evaluate(() => [LOADST.mode, LOADST.maxCFU, LOADST.defaultsV].join(' ')));
  // a later deliberate choice is kept
  await p.evaluate(() => { LOADST.mode = 'ignore'; LOADST.maxCFU = 40; save(); }); await p.waitForTimeout(400); await p.reload(); await p.waitForTimeout(1200);
  console.log('own choice kept:', await p.evaluate(() => [LOADST.mode, LOADST.maxCFU].join(' ')));
  console.log('errors', errs); await b.close();
})();
