import { WebR } from 'webr'; import fs from 'fs'; import { createRequire } from 'module';
import path from 'path'; import { fileURLToPath } from 'url';
const HERE = path.dirname(fileURLToPath(import.meta.url));
const DATA = (f) => path.resolve(HERE, 'data', f), M = (f) => path.resolve(HERE, '../method', f);
const LE = createRequire(import.meta.url)(path.resolve(HERE, '../load.js'));
const webR = new WebR({ baseUrl: path.resolve(HERE, '../node_modules/webr/dist') + '/', interactive: false }); await webR.init();
await webR.FS.writeFile('/tmp/fn.R', fs.readFileSync(M('loadEstimate.R')));
await webR.FS.writeFile('/tmp/ex.R', fs.readFileSync(M('reproduce_example.R')));
await webR.FS.mkdir('/w'); await webR.FS.writeFile('/w/COUNTS_plate01.csv', fs.readFileSync(DATA('plateA_counts.csv'))); await webR.FS.writeFile('/w/layout.csv', fs.readFileSync(DATA('layout_rows.csv')));
const out = await webR.evalRString(`setwd('/w'); source('/tmp/fn.R'); source('/tmp/ex.R'); paste(sprintf('%s|%.17g|%.17g|%.17g|%.17g', est$sampleID, est$log10_CFU_per_fly, est$se.logload, est$LOD_per_fly, est$code), collapse='\\n')`);
webR.close();
const R = Object.fromEntries(out.split('\n').map((l) => { const f = l.split('|'); return [f[0], f.slice(1).map(Number)]; }));
const lay = LE.buildLayout(LE.parseTable(fs.readFileSync(DATA('layout_rows.csv'), 'utf8')), 8, 12);
const { spots } = LE.spotsFromTable(LE.parseTable(fs.readFileSync(DATA('plateA_counts.csv'), 'utf8')), 'x', 'Prett', 5);
const res = LE.analyse(spots, lay, { mode: 'censor', maxCFU: 30, logbase: 10, homog: 250, dupAction: 'keep' });
let worst = 0; for (const f of res.flies) { const r = R[f.ID]; for (const [a, b] of [[f.log10_CFU_per_fly, r[0]], [f.se_log, r[1]], [f.LOD_per_fly, r[2]]]) worst = Math.max(worst, Math.abs(a - b) / Math.abs(b)); }
console.log('flies app', res.flies.length, 'R', Object.keys(R).length, '| worst rel diff app vs R example', worst.toExponential(2));
process.exit(0);
