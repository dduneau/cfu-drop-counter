// Image settings: shown on screen, used by detection, saved per plate, fast enough to browse with.
const path = require('path'), fs = require('fs');
const APP = 'file://' + path.resolve(__dirname, '../../index.html');
const D = (f) => path.resolve(__dirname, 'data', f), O = (f) => path.resolve(__dirname, 'out', f);
const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch(); const errs = [];
  const p = await (await b.newContext({ viewport: { width: 1180, height: 820 }, deviceScaleFactor: 2, acceptDownloads: true })).newPage(); p.on('pageerror', (e) => errs.push(e.message));
  await p.goto(APP); await p.waitForTimeout(300);
  await p.setInputFiles('#file', D('scan.jpg')); await p.waitForFunction(() => !document.querySelector('#to-grid').disabled);
  await p.click('#to-grid'); await p.evaluate(() => { S.grid.c = [[346, 325], [2683, 329], [340, 1784], [2679, 1785]]; });
  await p.click('[data-view=\"tune\"]'); await p.click('#detect-all'); await p.waitForFunction(() => S.view === 'count', null, { timeout: 60000 });
  const truth = {}; fs.readFileSync(D('COUNTS_25-06-17_1_plate01.csv'), 'utf8').trim().split(/\r?\n/).slice(1).forEach((l) => { const f = l.split(';'); truth[f[3]] = f[6]; });
  const score = async () => { const det = await p.evaluate(() => Object.fromEntries(Object.entries(S.wells).map(([k, w]) => [k, w.m.length]))); let ae = 0, n = 0, w2 = 0; for (const k in truth) if (truth[k] !== 'Inf' && k !== 'B7') { const e = Math.abs(det[k] - truth[k]); ae += e; n++; if (e <= 2) w2++; } return `MAE ${(ae / n).toFixed(2)}, within ±2 ${w2}/${n}`; };
  console.log('no adjustment:', await score());
  const set = (b, c, s) => p.evaluate(([b, c, s]) => { for (const [id, v] of [['#img-b', b], ['#img-c', c], ['#img-s', s]]) { const e = document.querySelector(id); e.value = v; e.dispatchEvent(new Event('input')); } }, [b, c, s]);
  const redetect = () => p.evaluate(async () => { await detectWells(Array.from({ length: nWells() }, (_, i) => i), '#c-prog'); });
  for (const [b, c, s] of [[0, 0.5, 0], [0, 1, 0], [0, 0, 1], [0, 0.5, 1], [-0.1, 0.5, 0], [0.1, 0, 0]]) {
    await set(b, c, s);
    const cleared = await p.evaluate(() => S.cal === null);
    await redetect(); console.log(`brightness ${b} contrast ${c} sharpness ${s}: calibration cleared ${cleared} | after detecting again: ${await score()}`);
  }
  // speed of browsing with view adjustments on (Count screen, display only)
  await p.click('[data-view="count"]'); await p.waitForTimeout(200);
  await p.evaluate(() => { for (const [id, v] of [['#v-b', 0.1], ['#v-c', 0.8], ['#v-s', 1.5]]) { const e = document.querySelector(id); e.value = v; e.dispatchEvent(new Event('input')); } });
  const calBefore = await p.evaluate(() => JSON.stringify(S.cal));
  let t = Date.now(); for (let k = 0; k < 5; k++) await p.click('#c-next2'); const ms = (Date.now() - t) / 5;
  await p.screenshot({ path: O('view-adjusted.png'), clip: { x: 0, y: 56, width: 812, height: 764 } });
  console.log('next drop with view adjustments:', Math.round(ms), 'ms per drop | view settings leave detection alone:', calBefore === (await p.evaluate(() => JSON.stringify(S.cal))), JSON.stringify(await p.evaluate(() => S.adj)));
  await set(0.1, 0.8, 1.5);
  // saved with the plate, carried to the next plate, in the progress file
  const [d] = await Promise.all([p.waitForEvent('download'), p.click('#c-progress')]); await d.saveAs(O('view-progress.json'));
  console.log('in progress file:', JSON.stringify(JSON.parse(fs.readFileSync(O('view-progress.json'), 'utf8')).state.adj));
  await p.click('[data-view="export"]'); await p.click('#x-nextplate'); await p.waitForTimeout(400);
  console.log('next plate starts from:', await p.evaluate(() => JSON.stringify(S.adj)));
  await p.evaluate(() => { S.adj = { b: 0, c: 0, s: 0 }; save(); }); await p.waitForTimeout(200);
  const first = await p.evaluate(() => PLATES[PLATES.length - 1].id); await p.click('[data-view="setup"]'); await p.click(`[data-popen="${first}"]`); await p.waitForFunction((id) => S.sid === id, first); await p.click('[data-view="tune"]'); await p.waitForTimeout(300);
  console.log('first plate keeps its own:', await p.evaluate(() => JSON.stringify(S.adj)), '| sliders', await p.evaluate(() => [document.querySelector('#img-b').value, document.querySelector('#img-c').value, document.querySelector('#img-s').value].join(' ')), '(after opening Tune)');
  console.log('errors', errs); await b.close();
})();
