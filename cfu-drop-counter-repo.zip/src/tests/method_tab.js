const path = require('path'), fs = require('fs');
const APP = 'file://' + path.resolve(__dirname, '../../index.html');
const O = (f) => path.resolve(__dirname, 'out', f);
const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch(); const errs = [];
  for (const [w, h, sc, tag] of [[1180, 820, 'light', 'method-ipad'], [400, 800, 'dark', 'method-phone']]) {
    const ctx = await b.newContext({ viewport: { width: w, height: h }, colorScheme: sc, acceptDownloads: true }); const p = await ctx.newPage(); p.on('pageerror', (e) => errs.push(e.message));
    await p.goto(APP); await p.waitForTimeout(300); await p.click('[data-view="method"]'); await p.waitForTimeout(200);
    await p.screenshot({ path: O(tag + '-0.png') });
    await p.evaluate(() => { const v = document.querySelector('#v-method'); v.scrollTop = document.querySelector('#rfunc').closest('.codebox').offsetTop - 60; }); await p.waitForTimeout(150);
    await p.screenshot({ path: O(tag + '-1.png') });
    console.log(tag, '| overflow', await p.evaluate(() => { const v = document.querySelector('#v-method'); return v.scrollWidth > v.clientWidth; }));
    if (tag === 'method-ipad') {
      const shown = await p.textContent('#rfunc'), file = fs.readFileSync(path.resolve(__dirname, '../method/loadEstimate.R'), 'utf8');
      console.log('R code shown verbatim:', shown === file);
      const [d] = await Promise.all([p.waitForEvent('download'), p.click('[data-save="rfunc"]')]);
      await d.saveAs(O('saved_loadEstimate.R')); console.log('saved', d.suggestedFilename(), 'identical', fs.readFileSync(O('saved_loadEstimate.R'), 'utf8') === file);
    }
  }
  console.log('errors', errs); await b.close();
})();
