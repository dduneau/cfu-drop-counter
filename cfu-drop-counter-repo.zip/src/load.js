// Per-fly load estimation: a line-by-line port of loadEstimateOneSample() and
// loadEstimate() from the lab's R utility file (as inlined in app.R), with
// R's uniroot(extendInt = "downX") and its Brent zeroin. Runs in browser and node.
const LoadEst = (() => {
  const DBL_EPS = 2.220446049250313e-16, DBL_MAX = Number.MAX_VALUE;

  // log(n!) for integer n >= 0 (exact sum of logs, cached)
  const lf = [0];
  function logFact(n) {
    for (let i = lf.length; i <= n; i++) lf[i] = lf[i - 1] + Math.log(i);
    return lf[n];
  }
  function logSumExp(a, b) { if (a === -Infinity) return b; if (b === -Infinity) return a; const m = Math.max(a, b); return m + Math.log(Math.exp(a - m) + Math.exp(b - m)); }
  function log1mexp(x) { return x > -Math.LN2 ? Math.log(-Math.expm1(x)) : Math.log1p(-Math.exp(x)); } // log(1 - e^x), x <= 0

  // dpois(k, lambda, log = TRUE) for integer k >= 0: Loader's saddle-point form, as in R's dpois_raw
  const SFERR_HALVES = [0.0, 0.1534264097200273452913848, 0.0810614667953272582196702, 0.0548141210519176538961390, 0.0413406959554092940938221, 0.03316287351993628748511048, 0.02767792568499833914878929, 0.02374616365629749597132920, 0.02079067210376509311152277, 0.01848845053267318523077934, 0.01664469118982119216319487, 0.01513497322191737887351255, 0.01387612882307074799874573, 0.01281046524292022692424986, 0.01189670994589177009505572, 0.01110455975820691732662991, 0.010411265261972096497478567, 0.009799416126158803298389475, 0.009255462182712732917728637, 0.008768700134139385462952823, 0.008330563433362871256469318, 0.007934114564314020547248100, 0.007573675487951840794972024, 0.007244554301320383179543912, 0.006942840107209529865664152, 0.006665247032707682442354394, 0.006408994188004207068439631, 0.006171712263039457647532867, 0.005951370112758847735624416, 0.005746216513010115682023589, 0.005554733551962801371038690];
  function stirlerr(n) {
    const S0 = 1 / 12, S1 = 1 / 360, S2 = 1 / 1260, S3 = 1 / 1680, S4 = 1 / 1188;
    if (n <= 15) { const nn = n + n; if (nn === Math.floor(nn)) return SFERR_HALVES[nn]; return logFact(n) - (n + 0.5) * Math.log(n) + n - 0.918938533204672741780329736406; }
    const nn = n * n;
    if (n > 500) return (S0 - S1 / nn) / n;
    if (n > 80) return (S0 - (S1 - S2 / nn) / nn) / n;
    if (n > 35) return (S0 - (S1 - (S2 - S3 / nn) / nn) / nn) / n;
    return (S0 - (S1 - (S2 - (S3 - S4 / nn) / nn) / nn) / nn) / n;
  }
  function bd0(x, np) {
    if (Math.abs(x - np) < 0.1 * (x + np)) {
      let v = (x - np) / (x + np), s = (x - np) * v;
      if (Math.abs(s) < 2.2250738585072014e-308) return s;
      let ej = 2 * x * v; v *= v;
      for (let j = 1; j < 1000; j++) { ej *= v; const s1 = s + ej / (2 * j + 1); if (s1 === s) return s1; s = s1; }
    }
    return x * Math.log(x / np) + np - x;
  }
  function ldpois(k, lambda) {
    if (lambda === 0) return k === 0 ? 0 : -Infinity;
    if (!isFinite(lambda)) return -Infinity;
    if (k < 0) return -Infinity;
    if (k <= lambda * 2.2250738585072014e-308) return -lambda;
    if (lambda < k * 2.2250738585072014e-308) return -lambda + k * Math.log(lambda) - logFact(k);
    return -stirlerr(k) - bd0(k, lambda) - 0.5 * Math.log(2 * Math.PI * k);
  }
  // log P(X <= k): sum of the k+1 terms, largest first
  function logLowerSum(k, lambda) {
    let s = -Infinity;
    for (let j = 0; j <= k; j++) s = logSumExp(s, ldpois(j, lambda));
    return s;
  }
  // log P(X > k): terms from k+1 until they stop mattering
  function logUpperSum(k, lambda) {
    let s = -Infinity, j = k + 1, t = ldpois(j, lambda);
    for (let n = 0; n < 100000; n++, j++) {
      t = ldpois(j, lambda);
      const ns = logSumExp(s, t);
      if (j > lambda && t - ns < -40) { s = ns; break; }
      s = ns;
    }
    return s;
  }
  // ppois(k, lambda, lower.tail, log.p = TRUE)
  function lppois(k, lambda, lower) {
    k = Math.floor(k);
    if (k < 0) return lower ? -Infinity : 0;
    if (lambda === 0) return lower ? 0 : -Infinity;
    // compute the smaller tail directly, the other by complement
    if (lambda < k + 1) { const up = logUpperSum(k, lambda); return lower ? log1mexp(up) : up; }
    const lo = logLowerSum(k, lambda); return lower ? lo : log1mexp(lo);
  }

  // R's C_zeroin2 (Brent), returning [root, iterations, estim.prec]
  function zeroin2(f, ax, bx, fa, fb, tol, maxIt) {
    let a = ax, b = bx, c = a, fc = fa, maxit = maxIt + 1, Maxit = maxIt;
    if (fa === 0) return [a, 0, 0];
    if (fb === 0) return [b, 0, 0];
    while (maxit--) {
      let prev_step = b - a, tol_act, p, q, new_step;
      if (Math.abs(fc) < Math.abs(fb)) { a = b; b = c; c = a; fa = fb; fb = fc; fc = fa; }
      tol_act = 2 * DBL_EPS * Math.abs(b) + tol / 2;
      new_step = (c - b) / 2;
      if (Math.abs(new_step) <= tol_act || fb === 0) return [b, Maxit - maxit, Math.abs(c - b)];
      if (Math.abs(prev_step) >= tol_act && Math.abs(fa) > Math.abs(fb)) {
        let t1, cb, t2;
        cb = c - b;
        if (a === c) { t1 = fb / fa; p = cb * t1; q = 1.0 - t1; }
        else { q = fa / fc; t1 = fb / fc; t2 = fb / fa; p = t2 * (cb * q * (q - t1) - (b - a) * (t1 - 1.0)); q = (q - 1.0) * (t1 - 1.0) * (t2 - 1.0); }
        if (p > 0) q = -q; else p = -p;
        if (p < (0.75 * cb * q - Math.abs(tol_act * q) / 2) && p < Math.abs(prev_step * q / 2)) new_step = p / q;
      }
      if (Math.abs(new_step) < tol_act) new_step = new_step > 0 ? tol_act : -tol_act;
      a = b; fa = fb;
      b += new_step; fb = f(b);
      if ((fb > 0 && fc > 0) || (fb < 0 && fc < 0)) { c = a; fc = fa; }
    }
    return [b, -1, -1];
  }
  // R's fcn2 wrapper: non-finite values replaced so the sign is kept
  const fcn2 = (f) => (x) => { const v = f(x); if (Number.isFinite(v)) return v; if (v === -Infinity) return -DBL_MAX; return DBL_MAX; };
  const truncate = (x) => Math.max(Math.min(x, DBL_MAX), -DBL_MAX);
  const isNA = (x) => x !== x;

  // uniroot(f, interval, extendInt = "downX") with R defaults; throws like R's stop()
  function unirootDownX(f, lower, upper) {
    const tol = Math.pow(DBL_EPS, 0.25), maxiter = 1000;
    if (!(lower < upper)) throw new Error("lower < upper  is not fulfilled");
    let fl = f(lower), fu = f(upper);
    if (isNA(fl)) throw new Error("f.lower = f(lower) is NA");
    if (isNA(fu)) throw new Error("f.upper = f(upper) is NA");
    const Sig = -1;
    let flo = truncate(fl), fup = truncate(fu);
    const doX = Sig * flo > 0 || Sig * fup < 0;
    let it = 0;
    if (doX) {
      const Delta = (u) => 0.01 * Math.max(1e-4, Math.abs(u));
      let delta = Delta(lower);
      while (Sig * fl > 0) { if (++it > maxiter) throw new Error("no sign change found"); fl = f(lower = lower - delta); delta *= 2; }
      delta = Delta(upper);
      while (Sig * fu < 0) { if (++it > maxiter) throw new Error("no sign change found"); fu = f(upper = upper + delta); delta *= 2; }
    }
    const sgn = (x) => (x > 0 ? 1 : x < 0 ? -1 : x === 0 ? 0 : NaN);
    if (!(sgn(fl) * sgn(fu) <= 0)) throw new Error(doX ? "did not succeed extending the interval endpoints" : "f() values at end points not of opposite sign");
    if (doX && it) { flo = truncate(fl); fup = truncate(fu); }
    const val = zeroin2(fcn2(f), lower, upper, flo, fup, tol, maxiter);
    return { root: val[0], iter: val[1], estim_prec: val[2] };
  }

  // loadEstimateOneSample(cfu, dilution, volume, maxCFU, ignoreAboveMaxCFU, logbase)
  // maxCFU: number, or NaN for NA (no ceiling). logbase: number or NaN.
  function oneSample(cfu, dilution, volume, maxCFU, ignoreAbove, logbase) {
    const noMax = isNA(maxCFU);
    const fail = (sum) => ({ logload: NaN, se_logload: NaN, load: NaN, se_load: NaN, code: -1, sumCFU: sum, maxCFU, ignoreAboveMaxCFU: ignoreAbove });
    const vol = (i) => (Array.isArray(volume) ? volume[i % volume.length] : volume);
    // NA filter (cfu and dilution only, as in the R source; callers drop NA rows first)
    const keep = cfu.map((x) => !isNA(x));
    const vdil = [], cf = [], dl = [];
    let k = 0;
    for (let i = 0; i < cfu.length; i++) if (keep[i]) { cf.push(cfu[i]); dl.push(dilution[i]); }
    for (let i = 0; i < dl.length; i++) vdil.push(dl[i] * vol(i));
    if (cf.length <= 0) return fail(0);
    if (cf.some((x) => x < 0)) throw new Error("CFU counts must be positive");
    if (dl.some((x) => x <= 0)) throw new Error("Dilution factors must be strinctly positive");
    if (dl.some((x) => x > 1)) throw new Error("Dilution cannot exceed one");
    const below = [], vBelow = [], vAbove = [];
    for (let i = 0; i < cf.length; i++) {
      const isBelow = noMax ? Number.isFinite(cf[i]) : cf[i] <= maxCFU;
      if (isBelow) { below.push(cf[i]); vBelow.push(vdil[i]); }
      if (!noMax && cf[i] > maxCFU) vAbove.push(vdil[i]);
    }
    // R's sum() accumulates in extended precision; compensated summation gives the same rounded result
    const rsum = (a) => { let s = 0, c = 0; for (const x of a) { const t = s + x; c += Math.abs(s) >= Math.abs(x) ? (s - t) + x : (x - t) + s; s = t; } return s + c; };
    const sum_cfu = rsum(below), sum_dil = rsum(vBelow);
    let first = Math.log(sum_cfu / sum_dil);
    if (first === Infinity || first === -Infinity) first = 0;
    const M = noMax ? 0 : Math.floor(maxCFU);
    const dllIgnore = (ll) => {
      const lambd = Math.exp(ll);
      let dll = -sum_dil + sum_cfu / lambd;
      if (!noMax) for (const dd of vBelow) { const avg = dd * lambd; const la = ldpois(M, avg) - lppois(M, avg, true); dll += dd * Math.exp(la); }
      return dll;
    };
    const dllCensor = (ll) => {
      const lambd = Math.exp(ll);
      let dll = -sum_dil + sum_cfu / lambd;
      if (!noMax) for (const dd of vAbove) { const avg = dd * lambd; const la = ldpois(M, avg) - lppois(M, avg, false); dll += dd * Math.exp(la); }
      return dll;
    };
    let opt;
    try { opt = unirootDownX(ignoreAbove ? dllIgnore : dllCensor, first - 5, first + 5); }
    catch (e) { return fail(sum_cfu); }
    if (isNA(opt.estim_prec)) return fail(sum_cfu);
    let est = opt.root;
    const lambd = Math.exp(est), lambd2 = lambd * lambd;
    let d2ll = -sum_cfu / lambd2;
    if (!noMax) {
      if (ignoreAbove) {
        for (const dd of vBelow) { const avg = lambd * dd; const lF = lppois(M, avg, true), lfv = ldpois(M, avg); const f_F = Math.exp(lfv - lF); d2ll += dd * dd * f_F * (f_F - 1 + maxCFU / avg); }
      } else {
        for (const dd of vAbove) { const avg = lambd * dd; const lF = lppois(M, avg, false), lfv = ldpois(M, avg); const f_F = Math.exp(lfv - lF); d2ll -= dd * dd * f_F * (f_F + (1 - maxCFU / avg)); }
      }
    }
    const d2 = [d2ll * lambd2, d2ll * 1];
    const se = d2.map((x) => (x < 0 ? 1 / Math.sqrt(-x) : NaN));
    if (!isNA(logbase) && logbase > 0) { const sc = Math.log(logbase); est = est / sc; se[0] = se[0] / sc; }
    return { logload: est, se_logload: se[0], load: lambd, se_load: se[1], code: 1, sumCFU: sum_cfu, maxCFU, ignoreAboveMaxCFU: ignoreAbove };
  }

  // ---------------- files, layout, joining, checks, per-fly table ----------------
  const GUESS = {
    well: ["WELL", "Well", "well", "Position"],
    id: ["ID", "Sample_ID", "Fly", "Fly_ID", "SampleID"],
    plate: ["Plate", "Plate name", "Plate.name", "PLATE", "plate"],
    row: ["ROW", "Row", "row"],
    col: ["COL", "Col", "col", "COLUMN", "Column", "column"],
    rep: ["Replicate", "Rep", "replicate"],
    vol: ["Volume", "volume", "Vol"],
    dil: ["Dilution", "dilution", "Dil"],
    cfu: ["CFU", "Colonies", "Count"],
  };
  const guess = (cols, k) => GUESS[k].find((g) => cols.includes(g)) || null;

  function guessSep(text) {
    const l = text.split(/\r?\n/).slice(0, 5).join("\n");
    const n = { ";": (l.match(/;/g) || []).length, ",": (l.match(/,/g) || []).length, "\t": (l.match(/\t/g) || []).length };
    return Object.keys(n).reduce((a, b) => (n[b] > n[a] ? b : a), ";");
  }
  function splitLine(line, sep) {
    const out = []; let cur = "", q = false;
    for (let i = 0; i < line.length; i++) {
      const ch = line[i];
      if (q) { if (ch === '"') { if (line[i + 1] === '"') { cur += '"'; i++; } else q = false; } else cur += ch; }
      else if (ch === '"') q = true;
      else if (ch === sep) { out.push(cur); cur = ""; }
      else cur += ch;
    }
    out.push(cur); return out.map((x) => x.trim());
  }
  function parseTable(text) {
    text = String(text).replace(/^﻿/, "");
    const sep = guessSep(text);
    const lines = text.split(/\r?\n/).filter((l) => l.trim() !== "");
    if (!lines.length) return { sep, cols: [], rows: [] };
    const cols = splitLine(lines[0], sep);
    const rows = lines.slice(1).map((l) => { const v = splitLine(l, sep), o = {}; cols.forEach((c, i) => (o[c] = v[i] ?? "")); return o; });
    return { sep, cols, rows };
  }
  const NA_STR = new Set(["", " ", ".", "NA", "na", "N/A"]);
  function num(x, sep) {
    x = String(x ?? "").trim(); if (NA_STR.has(x)) return NaN;
    if (sep !== ",") x = x.replace(",", ".");
    const v = Number(x); return isNaN(v) ? NaN : v;
  }
  // Inf, TNTC, lawn, confluent, ">..." read as too many to count
  function parseCfu(x) {
    x = String(x ?? "").trim();
    if (/^(inf|tntc|lawn|confluent)$/i.test(x) || /^>/.test(x)) return Infinity;
    if (NA_STR.has(x)) return NaN;
    const v = Number(x.replace(",", ".")); return isNaN(v) ? NaN : v;
  }
  function normWell(w) {
    w = String(w ?? "").toUpperCase().trim();
    const m = /^([A-P])\D*0*(\d+)$/.exec(w.replace(/\s+/g, ""));
    if (!m) return null; const c = +m[2]; return c >= 1 && c <= 48 ? m[1] + c : null;
  }
  function plateKey(x, mode) {
    x = String(x ?? "").trim();
    if (mode === "number") { const d = x.replace(/[^0-9]/g, ""); if (d) return String(parseInt(d, 10)); }
    return x;
  }
  // 0 or 1 = undiluted, 5 = 1/5; negative or missing = not usable
  const dilFrac = (f) => (isNaN(f) || f < 0 ? NaN : f <= 1 ? 1 : 1 / f);
  const cfuClass = (c, mx) => (!Number.isFinite(c) ? "too many" : !isNaN(mx) && c > mx ? "above the ceiling" : "countable");

  // Count columns a counts file offers: ours (columns between Dilution and the final NA) or generic ones.
  function countColumns(cols) {
    const di = cols.indexOf("Dilution");
    if (di >= 0 && di < cols.length - 1) { const t = cols.slice(di + 1); if (t[t.length - 1] === "NA") t.pop(); if (t.length) return t; }
    return GUESS.cfu.filter((g) => cols.includes(g));
  }
  // One counts file -> spots. type: a column name, or "*" for all count columns summed.
  function spotsFromTable(tab, fileName, type, defaultVolume) {
    const cols = tab.cols, info = { file: fileName, rows: tab.rows.length, problems: [] };
    const wc = guess(cols, "well"), pc = guess(cols, "plate"), rc = guess(cols, "rep"), vc = guess(cols, "vol"), dc = guess(cols, "dil");
    const ccs = countColumns(cols);
    const use = type === "*" ? ccs : ccs.includes(type) ? [type] : cols.includes(type) ? [type] : [];
    info.plateFrom = pc ? `column “${pc}”` : "file name";
    if (!wc) info.problems.push("no WELL column");
    if (!use.length) info.problems.push(type === "*" ? "no colony-count column" : `no “${type}” column`);
    if (!dc) info.problems.push("no Dilution column");
    const base = fileName.replace(/\.[^.]+$/, "");
    const spots = [];
    if (!wc || !use.length) return { spots, info };
    for (const r of tab.rows) {
      let cfu = 0;
      for (const c of use) { const v = parseCfu(r[c]); cfu = isNaN(v) || isNaN(cfu) ? NaN : cfu + v; }
      spots.push({
        source: fileName, plateRaw: pc ? String(r[pc] ?? "").trim() : base, well: normWell(r[wc]), cfu,
        rep: rc ? String(r[rc] ?? "").trim() : "1",
        volume: vc ? num(r[vc], tab.sep) : defaultVolume,
        dilFactor: dc ? num(r[dc], tab.sep) : NaN,
      });
    }
    return { spots, info };
  }
  // Layout -> rows of {plate|null, wells[], id, meta}
  const OUT_COLS = ["ID", "Plates", "Drops", "Countable", "Above_ceiling", "Too_many", "Total_CFU", "LOD_per_fly", "load", "logload", "se.logload", "sumCFU", "code", "CFU_per_fly", "log10_CFU_per_fly", "log2_CFU_per_fly", "se_log", "Status"];
  function buildLayout(tab, nRows, nCols) {
    const cols = tab.cols, L = { problems: [], notes: [] };
    const ic = guess(cols, "id"), wc = guess(cols, "well"), rc = guess(cols, "row"), cc = guess(cols, "col"), pc = guess(cols, "plate");
    L.idCol = ic; L.plateCol = pc; L.wellBy = wc ? "WELL" : rc ? "ROW" : cc ? "COL" : null;
    if (!ic) L.problems.push("no fly-identifier column (ID, Sample_ID, Fly, Fly_ID or SampleID)");
    if (!L.wellBy) L.problems.push("no WELL, ROW or COL column saying where each fly is");
    const used = [ic, wc, rc, cc, pc].filter(Boolean);
    const metaRaw = cols.filter((c) => !used.includes(c));
    L.renamed = metaRaw.filter((c) => OUT_COLS.includes(c));
    L.meta = metaRaw.map((c) => (OUT_COLS.includes(c) ? c + "_layout" : c));
    const R = "ABCDEFGHIJKLMNOP";
    L.rows = [];
    if (L.problems.length) return L;
    tab.rows.forEach((r, n) => {
      let wells = [];
      if (L.wellBy === "WELL") { const w = normWell(r[wc]); if (w) wells = [w]; }
      else if (L.wellBy === "ROW") { const x = String(r[rc] ?? "").trim().toUpperCase(); if (/^[A-P]$/.test(x)) for (let k = 1; k <= nCols; k++) wells.push(x + k); }
      else { const k = parseInt(String(r[cc] ?? "").replace(/[^0-9]/g, ""), 10); if (k >= 1 && k <= 48) for (let i = 0; i < nRows; i++) wells.push(R[i] + k); }
      const meta = {}; metaRaw.forEach((c, i) => (meta[L.meta[i]] = r[c]));
      L.rows.push({ n, plateRaw: pc ? String(r[pc] ?? "").trim() : null, wells, id: String(r[ic] ?? "").trim(), meta, bad: !wells.length });
    });
    return L;
  }

  // Everything after the files are read: joining, checks and estimates.
  // settings: {mode: 'ignore'|'censor'|'none', maxCFU, logbase, homog, dupAction: 'keep'|'first'}
  function analyse(spots, layout, settings) {
    const res = { blocking: [], warnings: [], tables: {} };
    const mx = settings.mode === "none" ? NaN : +settings.maxCFU;
    const byPlate = !!layout.plateCol;
    // plate matching: exact or by the number in the name, whichever joins more plates
    let match = "exact";
    if (byPlate) {
      const cnt = (m) => { const a = new Set(spots.map((s) => plateKey(s.plateRaw, m))), b = new Set(layout.rows.map((r) => plateKey(r.plateRaw, m))); let k = 0; for (const x of a) if (b.has(x)) k++; return k; };
      const ne = cnt("exact"), nn = cnt("number");
      if (nn > ne) { match = "number"; res.warnings.push({ kind: "info", text: `Plate names are spelled differently in the counts and the layout: ${ne} match exactly and ${nn} match on the number in the name, so the number is used.` }); }
      if (ne === 0 && nn === 0 && spots.length && layout.rows.length) res.blocking.push({ text: "No plate in the layout matches any plate in the counts, even by the number in the name. Check the Plate column of the layout against the plate names listed above." });
    }
    res.match = match;
    for (const s of spots) { s.plate = plateKey(s.plateRaw, match); s.dilFrac = dilFrac(s.dilFactor); }
    // layout index
    const lk = (p, w) => (byPlate ? p + "\u0001" + w : w);
    const flyAt = new Map(), dupWells = [], flies = new Map();
    for (const r of layout.rows) {
      const p = byPlate ? plateKey(r.plateRaw, match) : null;
      if (!flies.has(r.id)) flies.set(r.id, { id: r.id, meta: r.meta, order: flies.size });
      for (const w of r.wells) {
        const k = lk(p, w);
        if (flyAt.has(k) && flyAt.get(k) !== r.id) dupWells.push({ Plate: byPlate ? r.plateRaw : "(every plate)", Well: w, Flies: flyAt.get(k) + ", " + r.id });
        else flyAt.set(k, r.id);
      }
    }
    res.tables.dupWells = dupWells;
    if (dupWells.length) res.blocking.push({ text: `${dupWells.length} well(s) hold more than one fly in the layout.` });
    const badRows = layout.rows.filter((r) => r.bad).length;
    if (badRows) res.warnings.push({ text: `${badRows} layout row(s) give no readable well, row or column and were skipped.` });
    // duplicate spots: same plate name, well and replicate
    const seen = new Map(), dupSpots = [];
    for (const s of spots) { const k = s.plateRaw + "\u0001" + s.well + "\u0001" + s.rep; seen.set(k, (seen.get(k) || 0) + 1); }
    for (const [k, n] of seen) if (n > 1) { const [p, w, r] = k.split("\u0001"); dupSpots.push({ Plate: p, Well: w, Replicate: r, Times: n }); }
    res.tables.dupSpots = dupSpots;
    if (dupSpots.length) res.blocking.push({ text: `The same drop is recorded more than once (${dupSpots.length} drop${dupSpots.length === 1 ? "" : "s"}): usually the same plate added twice.` });
    // plate-name collisions under number matching
    if (match === "number") {
      const raw = new Map(); for (const s of spots) { if (!raw.has(s.plate)) raw.set(s.plate, new Set()); raw.get(s.plate).add(s.plateRaw); }
      const col = [...raw].filter(([, v]) => v.size > 1).map(([k, v]) => `${[...v].join(" and ")} (both read as ${k})`);
      if (col.length) res.blocking.push({ text: `Different plates collapse onto one number: ${col.join("; ")}. Rename the plates so each has its own number.` });
    }
    // join
    const merged = [];
    for (const s of spots) { const id = s.well ? flyAt.get(lk(s.plate, s.well)) : undefined; if (id !== undefined) merged.push({ ...s, id }); }
    // plates table
    const plates = new Map();
    for (const s of spots) { if (!plates.has(s.plate)) plates.set(s.plate, { Plate: s.plateRaw, names: new Set(), Spots: 0, Joined: 0, Flies: new Set(), Source: new Set() }); const p = plates.get(s.plate); p.names.add(s.plateRaw); p.Spots++; p.Source.add(s.source); }
    for (const m of merged) { const p = plates.get(m.plate); p.Joined++; p.Flies.add(m.id); }
    res.tables.plates = [...plates.values()].map((p) => ({ Plate: [...p.names].join(", "), Source: [...p.Source].join(", "), Drops: p.Spots, "Drops with a fly": p.Joined, Flies: p.Flies.size }));
    const noFly = res.tables.plates.filter((p) => p["Drops with a fly"] === 0);
    if (noFly.length && layout.rows.length) res.warnings.push({ text: `No fly from the layout sits on ${noFly.map((p) => p.Plate).join(", ")}.` });
    if (byPlate) {
      const lp = new Map(); for (const r of layout.rows) lp.set(plateKey(r.plateRaw, match), r.plateRaw);
      const missing = [...lp].filter(([k]) => !plates.has(k)).map(([, v]) => v);
      if (missing.length) res.warnings.push({ text: `The layout names plate(s) with no counts: ${missing.join(", ")}.` });
    }
    // colonies but no fly
    const orph = new Map();
    for (const s of spots) if (s.well && (s.cfu > 0) && flyAt.get(lk(s.plate, s.well)) === undefined) orph.set(s.plateRaw, (orph.get(s.plateRaw) || 0) + 1);
    res.tables.orphans = [...orph].map(([p, n]) => ({ Plate: p, "Drops with colonies": n }));
    if (orph.size) res.warnings.push({ text: `Some wells hold colonies but no fly in the layout (${[...orph.values()].reduce((a, b) => a + b, 0)} drop(s)).` });
    // the same dilution recorded twice for a fly
    merged.sort((a, b) => (a.plate < b.plate ? -1 : a.plate > b.plate ? 1 : a.well < b.well ? -1 : a.well > b.well ? 1 : 0));
    const cp = new Map();
    // spots without a dilution are left out anyway, so they are not compared
    for (const m of merged) { if (isNaN(m.dilFrac)) { m.copy = 1; continue; } const k = m.id + "\u0001" + m.dilFactor + "\u0001" + m.rep; m.copy = (cp.get(k) || 0) + 1; cp.set(k, m.copy); }
    for (const m of merged) m.nCopy = isNaN(m.dilFrac) ? 1 : cp.get(m.id + "\u0001" + m.dilFactor + "\u0001" + m.rep);
    const twice = merged.filter((m) => m.nCopy > 1 && m.copy <= 2 && Number.isFinite(m.cfu));
    if (twice.length) {
      const g = new Map();
      for (const m of twice) { const k = m.dilFactor + "\u0001" + m.rep; if (!g.has(k)) g.set(k, [{ p: new Set(), n: 0, c: 0 }, { p: new Set(), n: 0, c: 0 }]); const e = g.get(k)[m.copy - 1]; e.p.add(m.plateRaw); e.n++; e.c += m.cfu; }
      res.tables.twice = [...g].map(([k, [a, b]]) => ({ Dilution: k.split("\u0001")[0], "Plates (1st copy)": [...a.p].join(", "), "Colonies 1st": a.c, "Plates (2nd copy)": [...b.p].join(", "), "Colonies 2nd": b.c, Ratio: b.c ? Math.round((a.c / b.c) * 100) / 100 : NaN }));
      const off = res.tables.twice.filter((r) => r.Ratio > 2 || r.Ratio < 0.5).length;
      res.warnings.push({ text: `Some flies have the same dilution recorded twice (on ${res.tables.twice.length} dilution(s)). ` + (settings.dupAction === "first" ? "Only the first copy is used." : "Both copies are used, as replicate drops.") + (off ? ` ${off} ratio(s) are far from 1, which suggests a mislabelled dilution.` : "") });
    }
    // fraction-like factors
    const frac = [...new Set(spots.map((s) => s.dilFactor).filter((f) => f > 0 && f < 1))].sort();
    if (frac.length) res.warnings.push({ text: `Dilution factor(s) ${frac.join(", ")} are between 0 and 1. Factors are written as 1 (undiluted), 5 for 1/5, 25 for 1/25, so these are read as undiluted.` });
    const noDil = spots.filter((s) => isNaN(s.dilFrac)).length;
    if (noDil) res.warnings.push({ kind: "info", text: `${noDil} drop(s) have no dilution (a row or column marked as not spotted) and are left out.` });
    // counts per dilution
    let use = merged;
    if (settings.dupAction === "first") use = merged.filter((m) => m.copy === 1);
    const ser = new Map();
    for (const m of use) { const k = m.dilFactor; if (!ser.has(k)) ser.set(k, { Dilution: k, Drops: 0, Countable: 0, "Above ceiling": 0, "Too many": 0, c: [] }); const e = ser.get(k), st = cfuClass(m.cfu, mx); e.Drops++; if (isNaN(m.cfu)) continue; if (st === "countable") { e.Countable++; if (m.cfu > 0) e.c.push(m.cfu); } else if (st === "above the ceiling") e["Above ceiling"]++; else e["Too many"]++; }
    res.tables.series = [...ser.values()].sort((a, b) => a.Dilution - b.Dilution).map((e) => { const c = e.c.sort((a, b) => a - b); const med = c.length ? (c.length % 2 ? c[c.length >> 1] : (c[c.length / 2 - 1] + c[c.length / 2]) / 2) : NaN; const { c: _, ...r } = e; return { ...r, "Median countable": med }; });
    res.tables.dropped = [
      { Reason: "Well could not be read", Drops: spots.filter((s) => !s.well).length },
      { Reason: "No dilution set", Drops: noDil },
      { Reason: "No volume", Drops: spots.filter((s) => !(s.volume > 0)).length },
      { Reason: "Colony count missing (ignored drop)", Drops: spots.filter((s) => isNaN(s.cfu)).length },
      { Reason: "Drop in a well with no fly", Drops: Math.max(0, spots.length - merged.length) },
    ];
    res.nMerged = merged.length; res.nFlies = new Set(merged.map((m) => m.id)).size;
    if (res.blocking.length) return res;
    // estimation
    const d = use.filter((m) => !isNaN(m.cfu) && !isNaN(m.dilFrac) && !isNaN(m.volume));
    if (!d.length) { res.blocking.push({ text: "No drop has a count, a dilution and a volume." }); return res; }
    if (d.some((m) => m.cfu < 0)) { res.blocking.push({ text: "Some colony counts are negative." }); return res; }
    if (d.some((m) => !(m.dilFrac > 0 && m.dilFrac <= 1))) { res.blocking.push({ text: "Some dilutions are outside (0, 1] once converted from factors." }); return res; }
    if (d.some((m) => !(Number.isFinite(m.volume) && m.volume > 0))) { res.blocking.push({ text: "Some volumes are not a positive number." }); return res; }
    const per = new Map();
    for (const m of d) { if (!per.has(m.id)) per.set(m.id, []); per.get(m.id).push(m); }
    const base = +settings.logbase, homog = +settings.homog;
    const rows = [];
    const order = [...per.keys()].sort((a, b) => flies.get(a).order - flies.get(b).order);
    for (const id of order) {
      const sp = per.get(id);
      const e = oneSample(sp.map((m) => m.cfu), sp.map((m) => m.dilFrac), sp.map((m) => m.volume), mx, settings.mode === "ignore", base);
      const cls = sp.map((m) => cfuClass(m.cfu, mx));
      const r = { ID: id, ...flies.get(id).meta };
      r.Plates = [...new Set(sp.map((m) => m.plateRaw))].join(", ");
      r.Drops = sp.length; r.Countable = cls.filter((c) => c === "countable").length;
      r.Above_ceiling = cls.filter((c) => c === "above the ceiling").length; r.Too_many = cls.filter((c) => c === "too many").length;
      r.Total_CFU = sp.reduce((a, m) => a + (Number.isFinite(m.cfu) ? m.cfu : 0), 0);
      r.LOD_per_fly = homog / sp.reduce((a, m) => a + m.dilFrac * m.volume, 0);
      r.load = e.load; r.logload = e.logload; r["se.logload"] = e.se_logload; r.sumCFU = e.sumCFU; r.code = e.code;
      r.CFU_per_fly = e.load * homog;
      r[`log${base}_CFU_per_fly`] = Math.log(r.CFU_per_fly) / Math.log(base);
      r.se_log = e.se_logload;
      r.Status = !isNaN(r.CFU_per_fly) ? "Detected" : r.Countable === 0 ? "Above the dilutions used" : r.Total_CFU === 0 ? "Not detected" : "Estimation failed";
      rows.push(r);
    }
    res.flies = rows;
    res.columns = ["ID", ...layout.meta, "Plates", "Drops", "Countable", "Above_ceiling", "Too_many", "Total_CFU", "LOD_per_fly", "load", "logload", "se.logload", "sumCFU", "code", "CFU_per_fly", `log${base}_CFU_per_fly`, "se_log", "Status"];
    return res;
  }
  // R write.table(quote = TRUE) style, ';' separated
  function fmtNum(x) { if (x === Infinity) return "Inf"; if (x === -Infinity) return "-Inf"; if (x !== x) return "NA"; return String(+x.toPrecision(15)); }
  function toCSV(rows, columns, sep = ";") {
    const q = (s) => '"' + String(s).replace(/"/g, '""') + '"';
    const cell = (v) => (typeof v === "number" ? fmtNum(v) : v == null || v === "" ? "NA" : q(v));
    return [columns.map(q).join(sep), ...rows.map((r) => columns.map((c) => cell(r[c])).join(sep))].join("\n") + "\n";
  }

  return { oneSample, parseTable, spotsFromTable, countColumns, buildLayout, analyse, toCSV, dilFrac, normWell, plateKey, _internal: { ldpois, lppois, zeroin2, unirootDownX } };
})();
if (typeof module !== "undefined") module.exports = LoadEst;
