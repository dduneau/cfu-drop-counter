const path = require('path');
const APP = 'file://' + path.resolve(__dirname, '../../index.html');
const D = (f) => path.resolve(__dirname, 'data', f), O = (f) => path.resolve(__dirname, 'out', f);
const SAMPLE = path.resolve(__dirname, '../assets/sample.jpg');
const { chromium } = require('playwright'); const fs = require('fs');
(async () => {
  const b = await chromium.launch(); const errs = [];
  const ctx = await b.newContext({ acceptDownloads: true, viewport: { width: 1180, height: 820 } }); const p = await ctx.newPage();
  p.on('pageerror', (e) => errs.push(e.message));
  await p.goto(APP); await p.waitForTimeout(300);
  await p.setInputFiles('#file', D('scan.jpg')); await p.waitForFunction(() => !document.querySelector('#to-grid').disabled);
  await p.fill('[data-f="0"][data-k="value"]', '25-06-17'); await p.fill('[data-f="2"][data-k="value"]', 'plateA');
  // per-column dilution: 1, 5, 25 ... 5^11
  await p.click('#adv summary'); await p.click('#dilmode button[data-m="col"]');
  for (let k = 0; k < 12; k++) await p.fill(`[data-dil="${k}"]`, String(Math.pow(5, k)));
  await p.click('#to-grid'); await p.evaluate(() => { S.grid.c = [[346, 325], [2683, 329], [340, 1784], [2679, 1785]]; });
  await p.click('[data-view=\"tune\"]'); await p.click('#detect-all'); await p.waitForFunction(() => S.view === 'count', null, { timeout: 60000 });
  await p.evaluate(() => { for (let i = 0; i < 96; i++) W(i).seen = true; W(5).ign = true; }); // one ignored drop
  await p.click('[data-view="load"]'); await p.waitForTimeout(300);
  await p.screenshot({ path: O(O('shot-load-empty.png')), fullPage: true });
  await p.setInputFiles('#l-layout', D('layout_rows.csv')); await p.waitForTimeout(500);
  const flies = await p.evaluate(() => loadRes.res && loadRes.res.flies);
  console.log('flies', flies && flies.length, 'statuses', JSON.stringify(flies.reduce((a, f) => ((a[f.Status] = (a[f.Status] || 0) + 1), a), {})));
  console.log('flags', JSON.stringify(await p.$$eval('#l-flags .flag', (e) => e.map((x) => x.textContent.slice(0, 90)))));
  await p.screenshot({ path: O(O('shot-load.png')), fullPage: true });
  fs.writeFileSync(O('plateA_counts.csv'), await p.evaluate(() => buildCSV()));
  fs.writeFileSync(O('app_flies.json'), JSON.stringify(flies));
  const [d] = await Promise.all([p.waitForEvent('download'), p.click('#l-save')]);
  await d.saveAs(O('app_load.csv')); console.log('saved', d.suggestedFilename());
  const [d2] = await Promise.all([p.waitForEvent('download'), p.click('#l-save-set')]);
  await d2.saveAs(O('app_settings.txt'));
  // settings changes recompute
  await p.check('#l-mode input[value="censor"]'); await p.waitForTimeout(300);
  fs.writeFileSync(O('app_flies_censor.json'), JSON.stringify(await p.evaluate(() => loadRes.res.flies)));
  await p.click('#l-base button[data-b="2"]'); await p.waitForTimeout(300);
  console.log('log2 column present', await p.evaluate(() => loadRes.res.columns.includes('log2_CFU_per_fly')));
  await p.click('#l-base button[data-b="10"]'); await p.check('#l-mode input[value="ignore"]'); await p.waitForTimeout(200);
  // duplicate: add the same plate as a COUNTS file too
  await p.setInputFiles('#l-add', O('plateA_counts.csv')); await p.waitForTimeout(400);
  console.log('dup blocking:', JSON.stringify(await p.evaluate(() => loadRes.res.blocking.map((x) => x.text))));
  await p.click('[data-rmfile="0"]'); await p.waitForTimeout(200);
  console.log('files before reload', await p.evaluate(() => LOADST.files.length));
  // reload: load tab state persists
  await p.reload(); await p.waitForTimeout(1500); await p.click('[data-view="load"]'); await p.waitForTimeout(400);
  console.log('after reload: files', await p.evaluate(() => LOADST.files.length), 'blocking', await p.evaluate(() => JSON.stringify(loadRes.res && loadRes.res.blocking)));
  console.log('after reload flies', await p.evaluate(() => loadRes.res && loadRes.res.flies && loadRes.res.flies.length), 'layout', await p.evaluate(() => S.load.layout && S.load.layout.name));
  // multi-plate with no plate being counted: user's two replicate COUNTS files + well layout
  const ctx2 = await b.newContext({ viewport: { width: 1180, height: 820 } }); const q = await ctx2.newPage(); q.on('pageerror', (e) => errs.push(e.message));
  await q.goto(APP); await q.waitForTimeout(300);
  await q.click('[data-view="load"]'); await q.waitForTimeout(200);
  await q.setInputFiles('#l-add', [D('COUNTS_25-06-17_1_plate01.csv'), D('COUNTS_25-06-17_2_plate01.csv')]);
  await q.setInputFiles('#l-layout', D('layout_wells.csv')); await q.waitForTimeout(500);
  const r2 = await q.evaluate(() => ({ n: loadRes.res.flies.length, spots: loadRes.res.flies[0].Spots, t: loadRes.res.flies.reduce((a, f) => ((a[f.Status] = (a[f.Status] || 0) + 1), a), {}), flags: loadRes.res.warnings.map((w) => w.text.slice(0, 80)), dupRow: !document.querySelector('#l-dup-row').hidden }));
  console.log('two replicate files:', JSON.stringify(r2));
  await q.screenshot({ path: O(O('shot-load-multi.png')), fullPage: true });
  const ctx3 = await b.newContext({ viewport: { width: 400, height: 800 } }); const ph = await ctx3.newPage();
  await ph.goto(APP); await ph.waitForTimeout(300); await ph.click('[data-view="load"]'); await ph.waitForTimeout(200);
  console.log('phone overflow', await ph.evaluate(() => document.documentElement.scrollWidth > innerWidth || [...document.querySelectorAll('.view')].some((v) => !v.hidden && v.scrollWidth > v.clientWidth)));
  console.log('errors', errs); await b.close();
})();
