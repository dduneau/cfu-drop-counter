import path from 'path'; import { fileURLToPath } from 'url';
const HERE = path.dirname(fileURLToPath(import.meta.url));
const WEBR = path.resolve(HERE, '../node_modules/webr/dist') + '/';
const DATA = (f) => path.resolve(HERE, 'data', f);
const REF_R = path.resolve(HERE, 'loadEstimate_reference.R');
const LOADJS = path.resolve(HERE, '../load.js');
import { WebR } from 'webr';
import fs from 'fs';
import { createRequire } from 'module';
const require = createRequire(import.meta.url);
const LE = require(LOADJS);

// deterministic PRNG + Poisson sampler
let seed = 12345; const rnd = () => ((seed = (seed * 1103515245 + 12345) % 2147483648) / 2147483648);
const pois = (l) => { if (l > 500) { const n = Math.round(l + Math.sqrt(l) * gauss()); return Math.max(0, n); } let L = Math.exp(-l), k = 0, p = 1; do { k++; p *= rnd(); } while (p > L); return k - 1; };
const gauss = () => Math.sqrt(-2 * Math.log(rnd() + 1e-300)) * Math.cos(2 * Math.PI * rnd());
const cases = [];
const settings = [[50, true], [50, false], [30, true], [30, false], [100, true], [NaN, true], [NaN, false]];
const bases = [10, 2, NaN];
for (let n = 0; n < 1400; n++) {
  const step = [3, 5, 10, 100][n % 4], nd = 2 + Math.floor(rnd() * 11), reps = 1 + Math.floor(rnd() * 2);
  const lam = Math.pow(10, -2 + rnd() * 8); // per uL
  const cfu = [], dil = [], vol = [];
  for (let d = 0; d < nd; d++) for (let r = 0; r < reps; r++) {
    const f = Math.pow(step, d), v = [5, 5, 10, 2][n % 4];
    let c = pois(lam * v / f); if (c > 300 && rnd() < 0.8) c = Infinity;
    cfu.push(c); dil.push(1 / f); vol.push(v);
  }
  const [mx, ig] = settings[n % settings.length];
  cases.push({ cfu, dil, vol, mx, ig, lb: bases[n % 3] });
}
// edge cases
const E = (cfu, dil, vol, mx, ig, lb) => cases.push({ cfu, dil, vol, mx, ig, lb });
E([0, 0, 0], [1, 0.1, 0.01], [5, 5, 5], 50, true, 10);
E([0, 0, 0], [1, 0.1, 0.01], [5, 5, 5], 50, false, 10);
E([0], [1], [5], NaN, true, 10);
E([Infinity, Infinity], [1, 0.1], [5, 5], 50, true, 10);
E([Infinity, Infinity], [1, 0.1], [5, 5], 50, false, 10);
E([Infinity, 80, 60], [1, 0.1, 0.01], [5, 5, 5], 50, true, 10);
E([Infinity, 80, 60], [1, 0.1, 0.01], [5, 5, 5], 50, false, 10);
E([50, 5], [1, 0.1], [5, 5], 50, true, 10);
E([51, 5], [1, 0.1], [5, 5], 50, false, 2);
E([1], [1], [5], 50, true, 10);
E([1], [1e-6], [5], 50, true, 10);
E([3, 0, 0, 0], [1, 1 / 3, 1 / 9, 1 / 27], [5, 5, 5, 5], 50, true, 10);
E([Infinity, Infinity, Infinity, 45, 12, 6, 2, 0, 1, 0, 0, 0], Array.from({ length: 12 }, (_, i) => 1 / Math.pow(3, i)), Array(12).fill(5), 50, true, 10);
E([Infinity, Infinity, Infinity, 45, 12, 6, 2, 0, 1, 0, 0, 0], Array.from({ length: 12 }, (_, i) => 1 / Math.pow(3, i)), Array(12).fill(5), 50, false, 10);
E([Infinity, Infinity, Infinity, 45, 12, 6, 2, 0, 1, 0, 0, 0], Array.from({ length: 12 }, (_, i) => 1 / Math.pow(3, i)), Array(12).fill(5), NaN, true, 2);

const ser = (a) => a.map((x) => (x === Infinity ? 'Inf' : String(x))).join(',');
const txt = cases.map((c) => [ser(c.cfu), ser(c.dil), ser(c.vol), isNaN(c.mx) ? 'NA' : c.mx, c.ig ? 'TRUE' : 'FALSE', isNaN(c.lb) ? 'NA' : c.lb].join('|')).join('\n');

const webR = new WebR({ baseUrl: WEBR, interactive: false });
await webR.init();
await webR.FS.writeFile('/tmp/le.R', fs.readFileSync(REF_R));
await webR.FS.writeFile('/tmp/cases.txt', new TextEncoder().encode(txt));
const rOut = await webR.evalRString(`
  source('/tmp/le.R')
  L <- readLines('/tmp/cases.txt')
  out <- vapply(L, function(l) {
    p <- strsplit(l, '|', fixed = TRUE)[[1]]
    num <- function(s) as.numeric(strsplit(s, ',', fixed = TRUE)[[1]])
    r <- suppressWarnings(loadEstimateOneSample(num(p[1]), num(p[2]), num(p[3]), as.numeric(p[4]), as.logical(p[5]), as.numeric(p[6])))
    paste(sprintf('%.17g', c(r$logload, r$se.logload, r$load, r$se.load, r$code, r$sumCFU)), collapse = ',')
  }, '')
  paste(out, collapse = '\\n')`);
webR.close();
const R = rOut.split('\n').map((l) => l.split(',').map(Number));
const errs = []; let worst = 0, worstI = -1, fails = 0, codeMismatch = 0, nOk = 0, statuses = { ok: 0, fail: 0 };
const rel = (a, b) => (isNaN(a) && isNaN(b) ? 0 : isNaN(a) !== isNaN(b) ? Infinity : a === b ? 0 : Math.abs(a - b) / Math.max(1e-300, Math.abs(b)));
cases.forEach((c, i) => {
  let j; try { j = LE.oneSample(c.cfu, c.dil, c.vol, c.mx, c.ig, c.lb); } catch (e) { fails++; return; }
  const J = [j.logload, j.se_logload, j.load, j.se_load, j.code, j.sumCFU];
  if (J[4] !== R[i][4]) { codeMismatch++; console.log('code mismatch case', i, J, R[i]); }
  if (J[4] === 1) statuses.ok++; else statuses.fail++;
  // compare logload on absolute scale, others relative
  const ab = (a, b) => (isNaN(a) && isNaN(b) ? 0 : isNaN(a) !== isNaN(b) ? Infinity : Math.abs(a - b));
  const e = Math.max(ab(J[0], R[i][0]), rel(J[1], R[i][1]), rel(J[2], R[i][2]), rel(J[3], R[i][3]), ab(J[5], R[i][5]));
  errs.push(e);
  if (e > worst) { worst = e; worstI = i; }
});
console.log(`cases ${cases.length} | estimated ${statuses.ok}, failed (code -1) ${statuses.fail} | JS threw ${fails} | code mismatches ${codeMismatch}`);
errs.sort((a,b)=>a-b); console.log('median discrepancy', errs[errs.length>>1], '99th pct', errs[Math.floor(errs.length*0.99)]);
console.log('worst discrepancy', worst, 'case', worstI, worstI >= 0 ? JSON.stringify({ js: LE.oneSample(cases[worstI].cfu, cases[worstI].dil, cases[worstI].vol, cases[worstI].mx, cases[worstI].ig, cases[worstI].lb), r: R[worstI] }) : '');
process.exit(0);
