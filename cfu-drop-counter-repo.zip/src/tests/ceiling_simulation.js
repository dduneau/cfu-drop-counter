const path = require('path');
const APP = 'file://' + path.resolve(__dirname, '../../index.html');
const D = (f) => path.resolve(__dirname, 'data', f), O = (f) => path.resolve(__dirname, 'out', f);
const SAMPLE = path.resolve(__dirname, 'data', 'sample_old.jpg'); // the earlier example scan (reflected light)
const L = require(path.resolve(__dirname, '../load.js'));
let seed = 7; const rnd = () => ((seed = (seed * 1103515245 + 12345) % 2147483648) / 2147483648);
const gauss = () => Math.sqrt(-2 * Math.log(rnd() + 1e-300)) * Math.cos(2 * Math.PI * rnd());
const pois = (l) => { if (l > 400) return Math.max(0, Math.round(l + Math.sqrt(l) * gauss())); let Lm = Math.exp(-l), k = 0, p = 1; do { k++; p *= rnd(); } while (p > Lm); return k - 1; };
const facs = [1, 10, 100, 5, 25, 125, 3, 9, 27, 81], dil = facs.map((f) => 1 / f), vol = 5, M = 30;
// crowding: above ~15 colonies, merged colonies are missed (observed < true)
const observe = (c, crowd) => { if (c > 300) return Infinity; if (!crowd) return c; return Math.round(c / (1 + 0.012 * Math.max(0, c - 10))); };
for (const crowd of [false, true]) {
  console.log(crowd ? '\nWith undercounting of crowded drops (about -15% at 30 colonies):' : 'Counts exact:');
  console.log('true log10 CFU/fly | bias ignore | bias censor | RMSE ignore | RMSE censor | failed ign/cen');
  for (const t of [2.5, 3, 3.5, 4, 4.5, 5, 5.5]) {
    const lam = Math.pow(10, t) / 250; // per uL of homogenate
    let bi = 0, bc = 0, si = 0, sc = 0, ni = 0, nc = 0, fi = 0, fc = 0;
    for (let r = 0; r < 2000; r++) {
      const cfu = dil.map((d) => observe(pois(lam * vol * d), crowd));
      const a = L.oneSample(cfu, dil, vol, M, true, 10), c = L.oneSample(cfu, dil, vol, M, false, 10);
      const ti = Math.log10(a.load * 250), tc = Math.log10(c.load * 250);
      if (a.code === 1 && isFinite(ti)) { bi += ti - t; si += (ti - t) ** 2; ni++; } else fi++;
      if (c.code === 1 && isFinite(tc)) { bc += tc - t; sc += (tc - t) ** 2; nc++; } else fc++;
    }
    console.log(`${t.toFixed(1).padStart(18)} | ${(bi / ni).toFixed(3).padStart(11)} | ${(bc / nc).toFixed(3).padStart(11)} | ${Math.sqrt(si / ni).toFixed(3).padStart(11)} | ${Math.sqrt(sc / nc).toFixed(3).padStart(11)} | ${fi}/${fc}`);
  }
}

// ---- Near the top of the range: how often each setting overestimates badly (figures quoted in the Method tab) ----
{
  let seed = 7; const rnd = () => ((seed = (seed * 1103515245 + 12345) % 2147483648) / 2147483648);
  const gauss = () => Math.sqrt(-2 * Math.log(rnd() + 1e-300)) * Math.cos(2 * Math.PI * rnd());
  const pois = (l) => { if (l > 400) return Math.max(0, Math.round(l + Math.sqrt(l) * gauss())); let Lm = Math.exp(-l), k = 0, p = 1; do { k++; p *= rnd(); } while (p > Lm); return k - 1; };
  const dil = [1, 10, 100, 5, 25, 125, 3, 9, 27, 81].map((f) => 1 / f), M = 30, n = 4000;
  console.log('\nNear the top of the range (4,000 flies per load):');
  console.log('true log10 | one countable drop | estimated | >10x too high: leave out / keep | >2x too high: leave out / keep');
  for (const t of [4.5, 5.0, 5.2, 5.4, 5.5]) {
    const lam = Math.pow(10, t) / 250; const res = { ig: [], ce: [] }; let one = 0;
    for (let r = 0; r < n; r++) {
      const cfu = dil.map((d) => { const c = pois(lam * 5 * d); return c > 300 ? Infinity : c; });
      if (cfu.filter((c) => c <= M).length === 1) one++;
      for (const [k, ig] of [['ig', true], ['ce', false]]) { const e = L.oneSample(cfu, dil, 5, M, ig, 10); const v = Math.log10(e.load * 250); if (e.code === 1 && isFinite(v)) res[k].push(v - t); }
    }
    const over = (a, x) => a.filter((d) => d > x).length;
    console.log(`${t.toFixed(1).padStart(10)} | ${(100 * one / n).toFixed(0).padStart(17)}% | ${String(res.ig.length).padStart(9)} | ${over(res.ig, 1)} / ${over(res.ce, 1)} | ${over(res.ig, Math.log10(2))} / ${over(res.ce, Math.log10(2))}`);
  }
}
