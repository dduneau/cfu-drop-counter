const path = require('path');
const APP = 'file://' + path.resolve(__dirname, '../../index.html');
const O = (f) => path.resolve(__dirname, 'out', f);
const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch(); const errs = [];
  const p = await (await b.newContext({ viewport: { width: 1180, height: 820 }, hasTouch: true })).newPage(); p.on('pageerror', (e) => errs.push(e.message));
  await p.goto(APP); await p.waitForTimeout(300);
  await p.click('#btn-sample'); await p.waitForTimeout(700); await p.click('#to-grid'); await p.waitForTimeout(200); await p.click('[data-view=\"tune\"]'); await p.click('#detect-all'); await p.waitForFunction(() => S.view === 'count', null, { timeout: 60000 });
  await p.click('#c-next2'); await p.click('#c-next2'); await p.click('#c-next2'); await p.waitForTimeout(200);
  const pix = () => p.evaluate(() => { const c = document.querySelector('#c-canvas'); const d = c.getContext('2d').getImageData(0, 0, c.width, c.height).data; let h = 0; for (let i = 0; i < d.length; i += 97) h = (h * 31 + d[i]) >>> 0; return h; });
  const before = await pix(), marks = await p.evaluate(() => W(S.cur).m.length);
  const bb = await p.locator('#c-peek').boundingBox();
  await p.mouse.move(bb.x + 20, bb.y + 10); await p.mouse.down(); await p.waitForTimeout(150);
  const held = await pix(); await p.screenshot({ path: O('hide-held.png') });
  console.log('while held: image changed', held !== before, '| label', await p.textContent('#c-peek'), '| overlay', await p.textContent('#c-overlay'));
  await p.mouse.up(); await p.waitForTimeout(150);
  console.log('after release: image back', (await pix()) === before, '| marks unchanged', marks === (await p.evaluate(() => W(S.cur).m.length)));
  await p.keyboard.down('h'); await p.waitForTimeout(100); const kh = await pix(); await p.keyboard.up('h'); await p.waitForTimeout(100);
  console.log('H key: hidden', kh === held, '| shown again', (await pix()) === before);
  // a tap on the drop while hidden does nothing
  await p.evaluate(() => setPeek(true)); const box = await p.locator('#c-canvas').boundingBox(); await p.mouse.click(box.x + box.width / 2 + 120, box.y + box.height / 2 + 120);
  console.log('tap while hidden adds nothing:', marks === (await p.evaluate(() => W(S.cur).m.length))); await p.evaluate(() => setPeek(false));
  console.log('errors', errs); await b.close();
})();
