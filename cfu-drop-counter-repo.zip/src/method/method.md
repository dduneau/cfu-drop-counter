# Method

This tab describes how the Load step estimates the bacterial load of each fly. It gives the R code that defines the estimator, and an R example that reproduces the app's per-fly table.

## Model

Each fly's homogenate is spotted as drops at several dilutions. For drop *i* of a fly, let *v*ᵢ be the volume spotted (µL) and *d*ᵢ the dilution as a fraction (1 = undiluted, 1/25 = diluted 25-fold).

The number of colonies *y*ᵢ in the drop is modelled as **Poisson**, with mean

  *μ*ᵢ = *λ* · *v*ᵢ · *d*ᵢ

Here *λ* is the load per µL of homogenate, the one unknown for that fly. Drops are assumed independent.

## Spots above the ceiling

Colonies merge in crowded drops, so counts above a ceiling *M* (30 by default) are not read as exact. The setting **Spots with more colonies than can be read** decides what such a drop contributes to the likelihood:

| Setting | A drop with *y*ᵢ ≤ *M* contributes | A drop above *M*, or too many to count, contributes | Model |
|---|---|---|---|
| Keep them as counts known to exceed the ceiling (**default**) | P(*Y* = *y*ᵢ) | P(*Y* > *M*) | Censored Poisson |
| Leave them out, and correct the rest for the ceiling | P(*Y* = *y*ᵢ) / P(*Y* ≤ *M*) | nothing (left out) | Right-truncated Poisson |
| No ceiling | P(*Y* = *y*ᵢ) for every finite count | nothing (only drops marked too many) | Poisson |

Each probability is that of a Poisson variable *Y* with mean *μ*ᵢ. In R's function the first two settings are `ignoreAboveMaxCFU = FALSE` and `ignoreAboveMaxCFU = TRUE`, with `maxCFU` = *M*; the third is `maxCFU = NA`.

## Estimate and standard error

- **The estimate.** *λ̂* maximises the log-likelihood over all the fly's drops. It is found as the root of the score with respect to log *λ*, using R's `uniroot` with the interval extended as needed.
- **The standard error of log *λ̂*.** It is 1 / √(−ℓ″), where ℓ″ is the second derivative of the log-likelihood with respect to log *λ*, taken at the estimate (the observed information). It is reported on the log scale chosen (log10 or log2).
- **The load per fly** is *λ̂* × *V*, where *V* is the homogenate volume per fly (250 µL by default).
- **The detection limit per fly** is *V* / Σ *v*ᵢ *d*ᵢ, summed over all of that fly's drops. It is the load implied by a single colony over everything plated for that fly. It is not the load at which detection becomes reliable.

## Status of each fly

- **Detected**: a load was estimated.
- **Not detected**: every drop was countable and empty.
- **Above the dilutions used**: no drop was countable, so the load is higher than the series can measure.
- **Estimation failed**: none of the above applies.

## Assumptions to keep in mind

- **The standard error assumes pure Poisson variation between drops.** Extra variation, from pipetting or clumped bacteria, makes the real uncertainty larger than this standard error.
- **Counts at or below the ceiling are taken as exact.** If crowded drops near the ceiling are undercounted, the censored model inherits that error. A lower ceiling limits it.
- **The choice of ceiling setting.** In simulations of a 10-dilution series (1, 10, 100, 5, 25, 125, 3, 9, 27, 81; 5 µL drops; ceiling 30), keeping the spots above the ceiling gave estimates as precise or more precise than leaving them out at every load. At high loads, leaving them out produced large overestimates. That is why keeping them is the default.

## The estimator in R

The app runs a JavaScript translation of the two R functions below, line by line, including R's root finder and its Poisson probability functions. The translation was checked against this R code, run in R 4.6:

- On 1,415 simulated samples under every setting, the two agree to about 10⁻¹² and succeed or fail on the same samples.
- On a 48-fly, 8-plate data set, counts, statuses and detection limits are identical, and the loads agree to 10⁻¹³.

<!--RFUNC-->

## Reproducing the per-fly table in R

With the functions above loaded, this reads a counts file saved by the app and a layout file, and gives the same loads, standard errors and detection limits as the Load step, to about 10⁻¹².

<!--REXAMPLE-->
