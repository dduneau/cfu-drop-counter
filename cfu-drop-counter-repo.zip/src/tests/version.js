const path = require('path');
const APP = 'file://' + path.resolve(__dirname, '../../index.html');
const D = (f) => path.resolve(__dirname, 'data', f), O = (f) => path.resolve(__dirname, 'out', f);
const SAMPLE = path.resolve(__dirname, '../assets/sample.jpg');
const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch(); const p = await (await b.newContext({ viewport: { width: 1180, height: 820 } })).newPage(); const errs = []; p.on('pageerror', (e) => errs.push(e.message));
  await p.goto(APP); await p.waitForTimeout(300);
  console.log('header:', await p.textContent('.brand'), '| progress:', await p.evaluate(() => JSON.parse(buildProgress()).appVersion), '| settings:', await p.evaluate(() => loadSettingsText().split('\n')[2]));
  await p.screenshot({ path: O('ver.png'), clip: { x: 0, y: 0, width: 1180, height: 60 } }); console.log('errors', errs); await b.close();
})();
