// Colony detection for drop plates. Pure functions; runs in browser and node.
const CFUDetect = (() => {
  // Grey level from RGBA. Colonies are cream (high R,G); background dark.
  function toGray(rgba, n) {
    const g = new Float32Array(n);
    for (let i = 0, j = 0; i < n; i++, j += 4) g[i] = 0.4 * rgba[j] + 0.45 * rgba[j + 1] + 0.15 * rgba[j + 2];
    return g;
  }

  // Dark colonies on a light background (transmitted light): per-drop background
  // level = high percentile inside the counting area; output = darkness below it,
  // written back as grey so colonies become bright on dark, like reflective scans.
  function flattenDark(rgba, w, h, maskR, gain = 4, q = 0.9) {
    const n = w * h, g = toGray(rgba, n), cx = (w - 1) / 2, cy = (h - 1) / 2, vals = [];
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) if ((x - cx) ** 2 + (y - cy) ** 2 <= maskR * maskR) vals.push(g[y * w + x]);
    vals.sort((a, b) => a - b);
    const bg = vals.length ? vals[Math.floor((vals.length - 1) * q)] : 255;
    for (let i = 0, j = 0; i < n; i++, j += 4) { const v = Math.max(0, Math.min(255, (bg - g[i]) * gain)); rgba[j] = rgba[j + 1] = rgba[j + 2] = v; }
    return bg;
  }

  // Per component: highest level and edge sharpness (steep edge gradient relative to
  // depth). Out-of-focus smudges have soft edges; colonies have sharp ones.
  function compStats(g, lab, comps, w, h) {
    const N = comps.length + 1, mx = new Float64Array(N), ge = comps.map(() => []);
    for (let i = 0; i < lab.length; i++) if (lab[i] && g[i] > mx[lab[i]]) mx[lab[i]] = g[i];
    for (let y = 1; y < h - 1; y++) for (let x = 1; x < w - 1; x++) {
      const i = y * w + x, l = lab[i];
      if (!l) continue;
      if (lab[i - 1] === l && lab[i + 1] === l && lab[i - w] === l && lab[i + w] === l) continue; // interior
      // gradient just outside/at the edge: look 2 px around
      let gm = 0;
      for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) {
        const xx = x + dx, yy = y + dy; if (xx < 1 || yy < 1 || xx >= w - 1 || yy >= h - 1) continue;
        const j = yy * w + xx, gx = g[j + 1] - g[j - 1], gy = g[j + w] - g[j - w], v = Math.hypot(gx, gy) / 2;
        if (v > gm) gm = v;
      }
      ge[l - 1].push(gm);
    }
    return comps.map((c, k) => { const e = ge[k].sort((a, b) => a - b); return { max: mx[c.id], sharp: e.length ? e[Math.floor(e.length * 0.5)] / Math.max(1, mx[c.id]) : 0 }; });
  }

  function blur(src, w, h, sigma) {
    if (sigma < 0.3) return src;
    const rad = Math.max(1, Math.ceil(sigma * 2.5));
    const k = new Float32Array(2 * rad + 1);
    let s = 0;
    for (let i = -rad; i <= rad; i++) { k[i + rad] = Math.exp(-(i * i) / (2 * sigma * sigma)); s += k[i + rad]; }
    for (let i = 0; i < k.length; i++) k[i] /= s;
    const tmp = new Float32Array(w * h), out = new Float32Array(w * h);
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      let a = 0;
      for (let i = -rad; i <= rad; i++) { const xx = Math.min(w - 1, Math.max(0, x + i)); a += src[y * w + xx] * k[i + rad]; }
      tmp[y * w + x] = a;
    }
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      let a = 0;
      for (let i = -rad; i <= rad; i++) { const yy = Math.min(h - 1, Math.max(0, y + i)); a += tmp[yy * w + x] * k[i + rad]; }
      out[y * w + x] = a;
    }
    return out;
  }

  function circleMask(w, h, r) {
    const m = new Uint8Array(w * h), cx = (w - 1) / 2, cy = (h - 1) / 2;
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) if ((x - cx) ** 2 + (y - cy) ** 2 <= r * r) m[y * w + x] = 1;
    return m;
  }

  // 1-D squared distance transform (Felzenszwalb & Huttenlocher)
  function dt1(f, n, d, v, z) {
    let k = 0; v[0] = 0; z[0] = -Infinity; z[1] = Infinity;
    for (let q = 1; q < n; q++) {
      let s;
      while (true) {
        s = ((f[q] + q * q) - (f[v[k]] + v[k] * v[k])) / (2 * q - 2 * v[k]);
        if (s <= z[k]) { k--; if (k < 0) { k = 0; break; } } else break;
      }
      k++; v[k] = q; z[k] = s; z[k + 1] = Infinity;
    }
    k = 0;
    for (let q = 0; q < n; q++) { while (z[k + 1] < q) k++; d[q] = (q - v[k]) ** 2 + f[v[k]]; }
  }
  function edt(bin, w, h) {
    const INF = 1e10, n = Math.max(w, h);
    const f = new Float64Array(n), d = new Float64Array(n), v = new Int32Array(n), z = new Float64Array(n + 1);
    const g = new Float64Array(w * h);
    for (let i = 0; i < w * h; i++) g[i] = bin[i] ? INF : 0;
    for (let x = 0; x < w; x++) {
      for (let y = 0; y < h; y++) f[y] = g[y * w + x];
      dt1(f, h, d, v, z);
      for (let y = 0; y < h; y++) g[y * w + x] = d[y];
    }
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) f[x] = g[y * w + x];
      dt1(f, w, d, v, z);
      for (let x = 0; x < w; x++) g[y * w + x] = Math.sqrt(d[x]);
    }
    return g;
  }

  // Fill holes: background not connected to the outside becomes foreground.
  function fillHoles(bin, w, h) {
    const seen = new Uint8Array(w * h), st = [];
    const push = (i) => { if (!bin[i] && !seen[i]) { seen[i] = 1; st.push(i); } };
    for (let x = 0; x < w; x++) { push(x); push((h - 1) * w + x); }
    for (let y = 0; y < h; y++) { push(y * w); push(y * w + w - 1); }
    while (st.length) {
      const i = st.pop(), x = i % w, y = (i / w) | 0;
      if (x > 0) push(i - 1); if (x < w - 1) push(i + 1); if (y > 0) push(i - w); if (y < h - 1) push(i + w);
    }
    const out = new Uint8Array(w * h);
    for (let i = 0; i < w * h; i++) out[i] = bin[i] || !seen[i] ? 1 : 0;
    return out;
  }

  function components(bin, w, h) {
    const lab = new Int32Array(w * h), comps = [];
    let id = 0;
    for (let s = 0; s < w * h; s++) {
      if (!bin[s] || lab[s]) continue;
      id++; const st = [s]; lab[s] = id; let area = 0, sx = 0, sy = 0;
      while (st.length) {
        const i = st.pop(), x = i % w, y = (i / w) | 0; area++; sx += x; sy += y;
        const nb = [x > 0 ? i - 1 : -1, x < w - 1 ? i + 1 : -1, y > 0 ? i - w : -1, y < h - 1 ? i + w : -1];
        for (const j of nb) if (j >= 0 && bin[j] && !lab[j]) { lab[j] = id; st.push(j); }
      }
      comps.push({ id, area, cx: sx / area, cy: sy / area });
    }
    return { lab, comps };
  }

  function otsu(hist) {
    let total = 0, sum = 0;
    for (let i = 0; i < 256; i++) { total += hist[i]; sum += i * hist[i]; }
    let wB = 0, sumB = 0, best = 0, t = 128;
    for (let i = 0; i < 256; i++) {
      wB += hist[i]; if (!wB) continue;
      const wF = total - wB; if (!wF) break;
      sumB += i * hist[i];
      const mB = sumB / wB, mF = (sum - sumB) / wF, b = wB * wF * (mB - mF) ** 2;
      if (b > best) { best = b; t = i; }
    }
    return t;
  }

  // Prepare one drop: crop is a square RGBA centred on the drop.
  function prepare(drop, sigma) {
    const { rgba, w, h, maskR } = drop;
    const g = blur(toGray(rgba, w * h), w, h, sigma);
    return { g, w, h, mask: circleMask(w, h, maskR) };
  }

  function binarize(p, thr) {
    const { g, w, h, mask } = p, b = new Uint8Array(w * h);
    for (let i = 0; i < w * h; i++) b[i] = mask[i] && g[i] >= thr ? 1 : 0;
    return fillHoles(b, w, h);
  }

  // Plate-level calibration: one threshold and one colony radius for the plate.
  // dropPx = drop spacing in pixels, so defaults scale with scan resolution.
  function calibrate(drops, dropPx) {
    const sigma = Math.max(0.5, dropPx / 160);
    const preps = drops.map((d) => prepare(d, sigma));
    const hist = new Float64Array(256);
    for (const p of preps) for (let i = 0; i < p.g.length; i++) if (p.mask[i]) hist[Math.min(255, Math.max(0, p.g[i] | 0))]++;
    const threshold = otsu(hist);
    // Colony radius: from compact, isolated blobs (single colonies).
    const radii = [], areas = [];
    for (const p of preps) {
      const b = binarize(p, threshold), { lab, comps } = components(b, p.w, p.h), d = edt(b, p.w, p.h);
      const maxd = new Float64Array(comps.length + 1);
      for (let i = 0; i < lab.length; i++) if (lab[i] && d[i] > maxd[lab[i]]) maxd[lab[i]] = d[i];
      for (const c of comps) {
        const r = maxd[c.id];
        if (r < dropPx * 0.02) continue;
        const fill = c.area / (Math.PI * r * r);
        if (fill < 1.35) { radii.push(r); areas.push(c.area); }
      }
    }
    radii.sort((a, b) => a - b);
    let r0 = radii.length >= 3 ? radii[Math.floor(radii.length * 0.5)] : dropPx * 0.08;
    r0 = Math.min(dropPx * 0.2, Math.max(dropPx * 0.03, r0));
    areas.sort((a, b) => a - b);
    const a1 = areas.length >= 3 ? areas[Math.floor(areas.length * 0.6)] : Math.PI * r0 * r0;
    return { threshold, r0, a1, sigma, nSingles: radii.length };
  }

  function kmeans(lab, w, h, id, n, seeds) {
    const px = [];
    for (let i = 0; i < lab.length; i++) if (lab[i] === id) px.push(i % w, (i / w) | 0);
    const N = px.length / 2, cs = seeds.slice(0, n);
    // farthest-point seeding for the rest
    const dmin = new Float64Array(N).fill(Infinity);
    const upd = (c) => { for (let i = 0; i < N; i++) { const d = (px[2 * i] - c[0]) ** 2 + (px[2 * i + 1] - c[1]) ** 2; if (d < dmin[i]) dmin[i] = d; } };
    if (!cs.length) { let sx = 0, sy = 0; for (let i = 0; i < N; i++) { sx += px[2 * i]; sy += px[2 * i + 1]; } cs.push([sx / N, sy / N]); }
    cs.forEach(upd);
    while (cs.length < n) { let b = 0; for (let i = 1; i < N; i++) if (dmin[i] > dmin[b]) b = i; const c = [px[2 * b], px[2 * b + 1]]; cs.push(c); upd(c); }
    const as = new Int32Array(N);
    for (let it = 0; it < 12; it++) {
      for (let i = 0; i < N; i++) { let bd = Infinity, bj = 0; for (let j = 0; j < n; j++) { const d = (px[2 * i] - cs[j][0]) ** 2 + (px[2 * i + 1] - cs[j][1]) ** 2; if (d < bd) { bd = d; bj = j; } } as[i] = bj; }
      const acc = cs.map(() => [0, 0, 0]);
      for (let i = 0; i < N; i++) { const a = acc[as[i]]; a[0] += px[2 * i]; a[1] += px[2 * i + 1]; a[2]++; }
      for (let j = 0; j < n; j++) if (acc[j][2]) cs[j] = [acc[j][0] / acc[j][2], acc[j][1] / acc[j][2]];
    }
    return cs.map((c) => ({ x: c[0], y: c[1], v: 0, c: id }));
  }

  // Detect colonies in one drop. Returns centres in crop pixel coordinates.
  // opts: threshold, r0 (colony radius px), sigma, sensitivity (-1..1, + finds more), sizeFactor
  function detect(drop, opts) {
    const p = prepare(drop, opts.sigma);
    const thr = opts.threshold - (opts.sensitivity || 0) * 40;
    const b = binarize(p, thr), { w, h } = p;
    const { lab, comps } = components(b, w, h), d = edt(b, w, h);
    const r0 = opts.r0 * (opts.sizeFactor || 1);
    const minArea = Math.PI * r0 * r0 * 0.25;
    const maxd = new Float64Array(comps.length + 1);
    for (let i = 0; i < lab.length; i++) if (lab[i] && d[i] > maxd[lab[i]]) maxd[lab[i]] = d[i];
    // Thin bright features (well rim, plate edge, scratches) have a low distance-map peak.
    let keepC = comps.filter((c) => c.area >= minArea && maxd[c.id] >= r0 * (opts.thinK || 0.4));
    if (opts.dark) {
      // Transmitted-light scans: drop out-of-focus smudges (soft edges) and large dark
      // masses (saturated over a large part).
      const st = compStats(p.g, lab, comps, w, h), byId = new Map(comps.map((c, k) => [c.id, st[k]]));
      const sat = new Float64Array(comps.length + 1);
      for (let i = 0; i < lab.length; i++) if (lab[i] && p.g[i] >= 250) sat[lab[i]]++;
      const A1x = opts.a1 || Math.PI * r0 * r0;
      keepC = keepC.filter((c) => {
        const s = byId.get(c.id);
        if (s.sharp < (opts.softK || 0.06)) return false;
        if (c.area > 8 * A1x && sat[c.id] / c.area > (opts.darkK || 0.25)) return false;
        return true;
      });

    }
    const big = new Set(keepC.map((c) => c.id));
    // Candidate peaks: local maxima of the distance map.
    const cand = [];
    const R = 2;
    for (let y = R; y < h - R; y++) for (let x = R; x < w - R; x++) {
      const i = y * w + x, v = d[i];
      if (!big.has(lab[i]) || v < r0 * (opts.vmin || 0.3)) continue;
      let ok = true;
      for (let dy = -R; dy <= R && ok; dy++) for (let dx = -R; dx <= R; dx++) if (d[i + dy * w + dx] > v) { ok = false; break; }
      if (ok) cand.push({ x, y, v, c: lab[i] });
    }
    if (opts.mode === 'dog') {
      cand.length = 0;
      const gs = toGray(drop.rgba, w * h);
      const s1 = r0 * (opts.dogS || 0.6), g1 = blur(gs, w, h, s1), g2 = blur(gs, w, h, s1 * 1.6);
      const resp = new Float32Array(w * h);
      for (let i = 0; i < w * h; i++) resp[i] = g1[i] - g2[i];
      const RR = Math.max(2, Math.round(r0 * 0.4));
      for (let y = RR; y < h - RR; y++) for (let x = RR; x < w - RR; x++) {
        const i = y * w + x, v = resp[i];
        if (!big.has(lab[i]) || v <= (opts.dogMin || 0) || d[i] < r0 * 0.3) continue;
        let ok = true;
        for (let dy = -RR; dy <= RR && ok; dy += 1) for (let dx = -RR; dx <= RR; dx += 1) if (resp[i + dy * w + dx] > v) { ok = false; break; }
        if (ok) cand.push({ x, y, v, c: lab[i] });
      }
    }
    cand.sort((a, b) => b.v - a.v);
    // Local colony size: crowded drops grow smaller colonies. Use the ridge
    // height of the distance map (= colony radius along chains of colonies).
    let rl = r0;
    if (opts.adaptive !== false && opts.mode !== 'dog' && cand.length >= 4) {
      const vs = cand.map((c) => c.v).sort((a, b) => a - b);
      rl = Math.min(r0 * (opts.rmax || 1.3), Math.max(r0 * 0.45, vs[Math.floor(vs.length * (opts.rq || 0.35))]));
    }
    const pts = [], sep = rl * (opts.sepK || 1.0);
    for (const c of cand) {
      let ok = true;
      for (const q of pts) {
        const dist = Math.hypot(q.x - c.x, q.y - c.y);
        // allow closer peaks only if they are distinct (both well inside colonies)
        if (dist < (opts.mode === 'dog' ? r0 * (opts.sepK || 1.1) : Math.max(sep, Math.min(q.v, c.v) * 1.1))) { ok = false; break; }
      }
      if (ok) pts.push(c);
    }
    // Per blob: number of colonies = max(peaks, area / single-colony area).
    // Extra colonies in merged blobs are placed with k-means over blob pixels.
    const A1 = opts.a1 || Math.PI * r0 * r0;
    const byComp = new Map();
    for (const q of pts) { if (!byComp.has(q.c)) byComp.set(q.c, []); byComp.get(q.c).push(q); }
    const out = [];
    for (const c of comps) {
      if (!big.has(c.id)) continue;
      const peaks = byComp.get(c.id) || [];
      const nA = Math.round(c.area / (A1 * (rl / r0) ** 2 * (opts.areaK || 0.9)));
      const n = Math.max(1, peaks.length, nA);
      if (n === peaks.length) { out.push(...peaks); continue; }
      out.push(...kmeans(lab, w, h, c.id, n, peaks.map((q) => [q.x, q.y])));
    }
    pts.length = 0; pts.push(...out);
    let fg = 0, m = 0;
    for (let i = 0; i < b.length; i++) { if (p.mask[i]) { m++; if (b[i]) fg++; } }
    return { points: pts.map((q) => ({ x: q.x, y: q.y })), coverage: m ? fg / m : 0 };
  }

  return { calibrate, detect, flattenDark, blur };
})();
if (typeof module !== 'undefined') module.exports = CFUDetect;
